<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();

include('connection.php');

// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }


// $id = $_SESSION['id'];

$fname = $lname = $address = $city = $state = $mobile = $bddate = $gender = $age = $email = $password = $selectedState = "";
$success = "";
$error = $fnameErr = $lnameErr = $address1Err = $cityErr = $stateErr = $mobileErr = $bdateErr = $genderErr = $ageErr = $emailErr = $passwordErr = $cpasswordErr = "";

if ($_POST) {
  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  if (empty($_POST["fname"])) {
    $fnameErr = "First Name is required";
  } else {
    $fname = input_data($_POST["fname"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $fname)) {
      $fnameErr = "Only alphabets and white space are allowed";
    }
  }
  if (empty($_POST["lname"])) {
    $lnameErr = "Last Name is required";
  } else {
    $lname = input_data($_POST["lname"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $lname)) {
      $lnameErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["city"])) {
    $cityErr = "City is required";
  } else {
    $city = input_data($_POST["city"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $city)) {
      $cityErr = "Only alphabets and white space are allowed";
    }
  }
  if (empty($_POST["address"])) {
    $address1Err = "Address is required";
  } else{
    $address = $_POST["address"];
  }

  if (empty($_POST["gender"])) {
        $genderErr = "Gender is required";
    } else {
        $gender = input_data($_POST["gender"]);
    }


  if (empty($_POST["mobile"])) {
    $mobileErr = "Mobile no is required";
  } else {
    $mobile = input_data($_POST["mobile"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $mobile)) {
      $mobileErr = "Only numeric value is allowed.";
    }
    //check mobile no length should not be less and greator than 10  
    if (strlen($mobile) != 10) {
      $mobileErr = "Mobile no must contain 10 digits.";
    }
  }

  if (empty($_POST["bdate"])) {
    $bdateErr = "birth date is required";
  } else{
    $bddate = $_POST["bdate"];
  }

 // print_r($bddate );

  if ( empty($_POST['state'])) {
    $stateErr = "Please enter state ";
  } else {
    $state = $_POST['state'];
    // switch ($select3) {
    //   case 'maharashtra':
    //     $state = 'maharashtra';
    //     break;
    //   case 'gujrat':
    //     $state = 'gujrat';
    //     break;
    //   case 'punjab':
    //     $state = 'punjab';
    //     break;
    //   case 'tamilnadu':
    //     $state = 'tamilnadu';
    //     break;
    //   case 'rajasthan':
    //     $state = 'rajasthan';
    //     break;
    //   case 'karnataka':
    //     $state = 'karnataka';
    //     break;
    //   case 'goa':
    //     $state = 'goa';
    //     break;
    //   case 'hyderabad':
    //     $state = 'hyderabad';
    //     break;
    //   case 'bihar':
    //     $state = 'bihar';
    //     break;
    //   default:

    //     break;
    // }
  }
  $selectedState = isset($_POST['state']) ? $_POST['state'] : ''; 

  $age=$_POST['age'];
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = input_data($_POST["email"]);
    // check that the e-mail address is well-formed  
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = input_data($_POST["password"]);

    if (strlen($_POST["password"]) <= '8') {
        $passwordErr = "Your Password Must Contain At Least 8 Characters!";
    }
    elseif(!preg_match("#[0-9]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Number!";
    }
    elseif(!preg_match("#[A-Z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Capital Letter!";
    }
    elseif(!preg_match("#[a-z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Lowercase Letter!";
    } 
  }

  if (empty($_POST["cpassword"])) {
    $cpasswordErr = "Confirm password is required";
  } else {
    $cpassword = input_data($_POST["cpassword"]);
 
    if (strlen($_POST["cpassword"]) <= '8') {
        $cpasswordErr = "Your Password Must Contain At Least 8 Characters!";
    }
    elseif(!preg_match("#[0-9]+#",$cpassword)) {
        $cpasswordErr = "Your Password Must Contain At Least 1 Number!";
    }
    elseif(!preg_match("#[A-Z]+#",$cpassword)) {
        $cpasswordErr = "Your Password Must Contain At Least 1 Capital Letter!";
    }
    elseif(!preg_match("#[a-z]+#",$cpassword)) {
        $cpasswordErr = "Your Password Must Contain At Least 1 Lowercase Letter!";
    } 
  }

  if($_POST['password'] != $_POST['cpassword']){
     $cpasswordErr = "Your password and confirm password are different !!";
  }

  $password_string=$_POST['password'];

  $password=md5($_POST['password']);

  if ($fnameErr == "" && $lnameErr == "" && $address1Err == "" && $cityErr=="" && $stateErr=="" && $mobileErr=="" && $bdateErr=="" && $genderErr=="" && $ageErr=="" && $emailErr=="" && $passwordErr=="" && $error==""){
   // $link = new mysqli("localhost", "root", "root", "matrimonial_site");
   include('connection.php');
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {
        
        $query1 = "SELECT id FROM registration WHERE email='$email'";
        $result = mysqli_query($link, $query1);
        $count= mysqli_num_rows($result) ;

        // $id = mysqli_fetch_field($result);
        //print_r($result);

        // $query2 = "SELECT id FROM registration ";
        // $result2 = mysqli_query($link, $query2);
       // $row = mysqli_fetch_assoc($result);
        $_SESSION['id']=$result;
      // print_r( $_SESSION['id']);
        if($count > 0){
            $error = "<p class='text-danger'>Email address already exists </p>";
        }
        else{
            $query = $link->prepare("INSERT INTO registration(fname,lname,address,city,state,gender,mobile,age,dob,email,password) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
           
            $query->bind_param("sssssssisss", $fname, $lname, $address, $city, $state, $gender, $mobile, $age, $bddate, $email,$password);

            $query->execute();
            $query->close();
            $link->close();

            //print_r($fname);

            require 'PHPMailer/src/Exception.php';
            require 'PHPMailer/src/PHPMailer.php';
            require 'PHPMailer/src/SMTP.php';

            include ('smtp/PHPMailerAutoload.php');

            function smtp_mailer($to, $subject, $msg, $email, $password)
            {
                $mail = new PHPMailer(true); 

                try {
                    $mail->isSMTP();
                    $mail->Host = "smtp.gmail.com";
                    $mail->SMTPAuth = true;
                    $mail->Username = "webaccess03@gmail.com";
                    $mail->Password = "vkgkktdqzinaezpv";
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('webaccess03@gmail.com','Matrimonial Site');
                    $mail->addAddress($email);

                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->Subject = 'Login Details from Shaadi.com';
                    $mail->Body = '
                    <!DOCTYPE html>
                    <html lang="en">
                    
                    <head>
                      <meta charset="UTF-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">
                      <title>shaadi.com</title>
                    
                      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
                        
                    </head>
                    
                    <body>
                    
                            
                            <div class="mt-5">
                              <h1>Welcome to Shaadi.com</h1>
                              <p>We believe choosing a life partner is a big and important decision, and hence work towards giving a simple and secure matchmaking experience for you and your family. Each profile registered with us goes through a manual screening process before going live on site; we provide superior privacy controls for Free; and also verify contact information of members.</p>
                            </div>
                    
                            <div class="mt-5 mb-5">
                              <h3 class="mt-5">Login Details from Shaadi.com</h3>
                              <p>Email : '.$email.'</p>
                              <p>Password : '.$password.' </p>
                            </div>
                                             
                    
                    </body>
                    
                    </html>
                    ';

                    if (!$mail->send()) {
                        return 'Error: ' . $mail->ErrorInfo;
                    } else {
                        return 'Sent';
                    }
                } catch (Exception $e) {
                    return 'Error: ' . $mail->ErrorInfo;
                }
            }

           smtp_mailer('webaccess03@gmail.com', 'Mail has send successfully', 'Hello Komal', $email, $password_string);

           //header('Location: login.php');
           echo '<script> 
           window.onload = function() {
            display_pop();
          };  </script>';
        }
      
    }
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #loginbtn{
        margin-left: 1000px;
    }
    #gender{
      margin-left: 10px
    }
    a
    {  color:white; 
        text-decoration: none;
    }
    a:hover
    {  color: white;
        text-decoration: none;
        
    }
    #anchor{
        color:blue;
        text-decoration: underline;
    }
    #all{
      color : red; 
    }
   
  </style>
</head>

<body>

<script>
        function calculateAge() {
            // Get the selected birthdate from the input
            var dob = document.getElementById("mybdate").value;

            // Split the date string into year, month, and day
            var parts = dob.split("-");
            var year = parseInt(parts[0], 10);
            var month = parseInt(parts[1], 10);
            var day = parseInt(parts[2], 10);

            // Get today's date
            var today = new Date();

            // Calculate age
            var age = today.getFullYear() - year;
            var m = today.getMonth() + 1 - month;
            if (m < 0 || (m === 0 && today.getDate() < day)) {
                age--;
            }

            // Display the age
            var input = document.getElementById("age");
            input.value = age;
        }


      function display_pop(){
        Swal.fire({
        title: "Registered Successfully !!",
        showClass: {
          popup: `
            animate__animated
            animate__fadeInUp
            animate__faster
          `
        },
        hideClass: {
          popup: `
            animate__animated
            animate__fadeOutDown
            animate__faster
          `
        }
      })
    .then(function() {
    window.location = "login.php";
});
}

</script>

  <nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">shaadi.com</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item mx-2">
            <a class="nav-link " aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about-us.php">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us.php">Contact Us</a>
          </li>
          


        </ul>
            <button class="btn btn-outline-success mr-sm-2" type="submit" id="loginbtn">
            <a href="login.php">Log In</a></button>
      </div>
    </div>
  </nav>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Registration Form</h1>
    

    <div class="col-lg-10 mx-auto col-md-4 d-flex justify-content-center ">
        
    <form class="p-4 p-md-5 border rounded-3 bg-light col-sm-9" name="registration-form" method="post">

            <div class="row mb-2 ">
                <div class="col-lg-6">
                    <label class="form-label " for="fname">First Name</label>
                    <input class="form-control " name="fname" id="fname" aria-describedby="namePrepend" type="text"
                    placeholder="First Name" value="<?php echo $fname ?>">
                    <p class="error" id="fnerr">
                    <?php echo $fnameErr; ?>
                    </p>
                </div>
                <div class="col-lg-6">
                    <label class="form-label " for="lname">Last Name</label>
                    <input class="form-control " name="lname" id="lname" type="text" placeholder="Last Name" value="<?php echo $lname ?>">
                    <p class="error" id="lnerr">
                    <?php echo $lnameErr; ?>
                    </p>
                </div>
            </div>  

            <div class="form-group mb-3 mt-2">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email ?>">
                        <p class="error" id="emailerr">
                            <?php echo $emailErr; ?>
                        </p>
            </div>

            <div class="row mb-2 ">
                <div class="col-lg-6">
                    <div class="form-group mb-3 mt-2">
                        <label class="form-label" for="password">Password</label>
                        <input class="form-control" type="password" name="password" id="password" placeholder="Password">
                        <p class="error" id="passworderr">
                        <?php echo $passwordErr; ?>
                        </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group mb-3 mt-2">
                        <label class="form-label" for="cpassword">Confirm Password</label>
                        <input class="form-control" type="password" name="cpassword" id="cpassword" placeholder="Confirm Password">
                        <p class="error" id="passworderr">
                        <?php echo $cpasswordErr; ?>
                        </p>
                    </div>
                </div>
            </div>      

            <div class="form-group mb-3 mt-2">
                <label for="address">Address</label>
                <input type="text" class="form-control" name="address" id="address" placeholder="Address" value="<?php echo $address ?>">
                <p class="error" id="add1err">
                    <?php echo $address1Err; ?>
                </p>
            </div>

            <div class="row mb-2 ">
                <div class="col-lg-6 ">
                    <div class="form-group ">
                        <label for="inputCity">City</label>
                        <input type="text" class="form-control" name="city" id="inputCity" placeholder="Enter City" value="<?php echo $city ?>">
                        <p class="error" id="cityerr">
                        <?php echo $cityErr; ?>
                        </p>
                    </div>
                </div>
                <div class="ddate mb-3 col-lg-6">
                <div class="form-group ">
                        <div><label class="form-label" for="state">State</label></div>
                        <select name="state" class="form-select p-1 " style="width:250px; height:39px;">
                            <option value="" disabled <?php if ($selectedState == '') echo 'selected'; ?>>Select Any</option>
                            <option value="Maharashtra" <?php if ($selectedState == 'Maharashtra') echo 'selected'; ?>>Maharashtra</option>
                            <option value="Gujrat" <?php if ($selectedState == 'Gujrat') echo 'selected'; ?>>Gujrat</option>
                            <option value="Punjab" <?php if ($selectedState == 'Punjab') echo 'selected'; ?>>Punjab</option>
                            <option value="Tamilnadu" <?php if ($selectedState == 'Tamilnadu') echo 'selected'; ?>>Tamilnadu</option>
                            <option value="Rajasthan" <?php if ($selectedState == 'Rajasthan') echo 'selected'; ?>>Rajasthan</option>
                            <option value="Karnataka" <?php if ($selectedState == 'Karnataka') echo 'selected'; ?>>Karnataka</option>
                            <option value="Goa" <?php if ($selectedState == 'Goa') echo 'selected'; ?>>Goa</option>
                            <option value="Hyderabad" <?php if ($selectedState == 'Hyderabad') echo 'selected'; ?>>Hyderabad</option>
                            <option value="Bihar" <?php if ($selectedState == 'Bihar') echo 'selected'; ?>>Bihar</option>
                        </select>
                        <p class="error" id="stateerr">
                            <?php echo $stateErr; ?>
                        </p>
                    </div>
                </div>
            </div> 

            

            <div class="row mb-2 ">
                <div class="col-lg-6 ">
                    <label class="form-label" for="mobile">Phone No.</label>
                    <input class="form-control" type="tel" name="mobile" id="mobile" placeholder="Phone No." maxlength="10" value="<?php echo $mobile ?>">
                    <p class="error" id="mnerr">
                    <?php echo $mobileErr; ?>
                    </p>
                </div>
                <div class="ddate mb-3 col-lg-6">
                        <label for="bdate" class="form-label" id="bdate">Birth Date</label>
                        <input class="form-control" type="date" name="bdate" id="mybdate" width="900px" max='2010-01-01' value="<?php echo $bddate; ?> " onchange="calculateAge()">
                        
                        <p class="error" id="bdate">
                                <?php echo $bdateErr; ?>
                        </p>
                </div>
            </div>  

              

            <div class="row mb-2 ">
            <div class="col-lg-6 form-floating mb-3 p-2 ml-4">
                <div class="row"><label for="inputState" class="form-label text-lg-start">Gender 
                            </label></div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="male" value="Male" <?php if($gender =="Male"){ echo 'checked="checked"'; } ?>>
                            <label class="form-check-label" for="flexRadioDefault1">
                                Male
                            </label>
                    </div>
                    <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="female" value="Female" <?php if($gender =="Female"){ echo 'checked="checked"'; } ?>>
                            <label class="form-check-label" for="flexRadioDefault2">
                                Female
                            </label>
                    </div>
                    <span class="error"> <?php echo $genderErr;?></span>

                    
                </div>
                <div class="ddate mb-3 col-lg-5 p-0" style="margin-right: 30px">
                <label for="age">Age</label>
                        <input type="number" class="form-control" name="age" id="age" placeholder="Age" onKeyPress="if(this.value.length==2) return false;">  
                  <!-- <div id="age"></div> -->
                </div>    
            </div>

            

            <div class="text-center">
                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text" id="register" name="register" 
                    value="Register Now" > Register Now!
                    <!-- <a href="login.php"> Register Now! </a> -->
                </button>

                <?php echo $error; ?>
                
                <p class="text-center mt-3">Already registered? <a id="anchor" href="login.php">Log in</a></p>
            </div>
        </form>
    </div>
</div>





  <div class="container">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>


</body>

</html>