<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

// $id="";
// if(isset($_SESSION['id'])){
//   $id=$_SESSION['id'];
// }

// if(!empty($id)){
//   header('Location: home.php');
//   return;
// }
// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }
include('connection.php');
// $id = $_SESSION['id'];

$email = $password = "";
$success = "";
$emailErr = $passwordErr = $error = "";

if ($_POST) {
  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }


  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = input_data($_POST["email"]);
    // check that the e-mail address is well-formed  
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
  } else {
    $password = input_data($_POST["password"]);
    // check that the e-mail address is well-formed  
    if (strlen($_POST["password"]) <= '8') {
        $passwordErr = "Your Password Must Contain At Least 8 Characters!";
    }
    elseif(!preg_match("#[0-9]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Number!";
    }
    elseif(!preg_match("#[A-Z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Capital Letter!";
    }
    elseif(!preg_match("#[a-z]+#",$password)) {
        $passwordErr = "Your Password Must Contain At Least 1 Lowercase Letter!";
    } 
  }

  $password=md5($_POST['password']);
  
  if ($emailErr=="" && $passwordErr=="" && $error=="") {
    //$link = new mysqli("localhost", "root", "root", "matrimonial_site");
    include('connection.php');
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {
        $query = "SELECT * FROM registration WHERE email='$email' AND password='$password'";
        $result = mysqli_query($link, $query);
        
        if ($result) {
           
            if (mysqli_num_rows($result) > 0) {

              $query1 = "SELECT id FROM registration WHERE email='$email'";
              $result = mysqli_query($link, $query1);
            $id= mysqli_fetch_assoc($result) ;

              $_SESSION['id'] = $id['id'];

                if (isset ($_POST['stayLoggedIn'])) 
                {
                  setcookie('uid', $id['id'], time() + (86400 * 30) );
                }
               
               //header('Location: home.php');
               echo '<script> 
                    window.onload = function() {
                      display_pop();
                    };  </script>';
        
            } else {

                $error = "<p class='text-danger text-center'>Please check email and password!</p>";
            }
       
        }
    }
  }

}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #loginbtn{
        margin-left: 1000px;
    }
    #gender{
      margin-left: 10px
    }
    a
    {  color:white; 
        text-decoration: none;
    }
    a:hover
    {  color: white;
        text-decoration: none;
        
    }
    #anchor{
        color:blue;
        text-decoration: underline;
    }
  </style>
</head>

<body>

<script>
      function display_pop() {
      Swal.fire({
        title: "Log In Successfully",
        showClass: {
          popup: `
            animate__animated
            animate__fadeInUp
            animate__faster
          `
        },
        hideClass: {
          popup: `
            animate__animated
            animate__fadeOutDown
            animate__faster
          `
        }
      })
      .then(function() {
    window.location = "home.php";
      });
  } 
</script>


  <nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">shaadi.com</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item mx-2">
            <a class="nav-link " aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about-us.php">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us.php">Contact Us</a>
          </li>
          


        </ul>
            <button class="btn btn-outline-success mr-sm-2" type="submit" id="loginbtn"><a href="login.php">Log In</a></button></button>
      </div>
    </div>
  </nav>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Log-In </h1>
    <div class="col-lg-10 mx-auto col-md-4 d-flex justify-content-center">
        <form class="p-4 p-md-5 border rounded-3 bg-light col-sm-5 " name="login-form" method="post">
           
            <div class="form-group mb-3 mt-2">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" id="email" placeholder="Email">
                <p class="error" id="emailerr">
                    <?php echo $emailErr; ?>
                </p>
            </div>

            <div class="form-group mb-3 mt-2">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" type="password" name="password" id="password" placeholder="Password">
                <p class="error" id="passworderr">
                  <?php echo $passwordErr; ?>
                </p>
            </div>

            <div class="text-center mb-3">
                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text" id="login" name="login"
                    value="LogIn">LogIn 
                </button>
            </div>
            <?php echo $error; ?>
            <div class="form-check text-center mb-3">
              <input class="form-check-input" type="checkbox" value="Stay Logged In" id="stayLoggedIn" name="stayLoggedIn">
              <label class="form-check-label" for="stayLoggedIn">
                Stay Logged In
              </label>
            </div>
            <p class="text-center">New to Shaadi? <a id="anchor" href="registration-form.php">Register here</a></p>
        </form>
    </div>
</div>








  <div class="container">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>



</body>

</html>