
<link rel="stylesheet" href="stylesheet.css">

<section class="msger" style="display: none; ">
  <header class="msger-header">
    <div class="msger-header-title">
      <i class="fas fa-comment-alt"></i> Chat-box
    </div>
    <div class="msger-header-options">
      <span><i class="fas fa-cog"></i></span>
    </div>
  </header>

 <?php

  include('connection.php');

  $id = $_SESSION['id'];

  $query = "SELECT fname FROM registration where id=$id";
  $result = mysqli_query($link, $query);
  $row = mysqli_fetch_assoc($result);
  $name=$row['fname'];

 // print_r($profile_id);

  $query="SELECT personal.fname,c.msg FROM chats c
        INNER JOIN personal ON personal.resiterid=c.sender_id
        WHERE ((c.sender_id=$profile_id AND c.rec_id=$id) OR (c.sender_id=$id AND c.rec_id=$profile_id)) ORDER BY date DESC;";

$result = mysqli_query($link, $query);
//print_r($result);
 $oldchats= mysqli_fetch_all($result);


 //print_r($name);
  ?>
  <main class="msger-chat" id="message-box">
      

  </main>

  <div class="msger-inputarea">
    <input type="text" class="msger-input" id="message" placeholder="Enter your message...">
    <input type="hidden" class="msger-input" id="name" value="<?php echo  $name; ?>">

    <button type="button" class="msger-send-btn" id="send-message">Send</button>
</div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script language="javascript" type="text/javascript">  
 
  var msgBox = $('#message-box');
	var wsUri = "ws://localhost:9000/chat/server.php"; 	
	websocket = new WebSocket(wsUri); 
	
	websocket.onopen = function(ev) { // connection is open 
		msgBox.append('<div class="system_msg" style="color:#bbbbbb">Welcome to my "Shaadi.com Chat"!</div>'); //notify user
	}
	// Message received from server
		
	websocket.onmessage = function(ev) {
		var response 		= JSON.parse(ev.data); //PHP sends Json data
    var sid = response.sid;
    var rid = response.rid;
    if(((sid==<?php echo $id; ?>) && (rid==<?php echo $profile_id; ?>)) || ((sid==<?php echo $profile_id; ?>) && (rid==<?php echo $id; ?>))){
      var res_type 		= response.type; //message type
		  var user_message 	= response.message; //message text
  
		var user_name 		= response.name; //user name
		var user_color 		= response.color; //color
		if(((sid==<?php echo $profile_id; ?>) && (rid==<?php echo $id; ?>))){
			markRead(sid,rid);
			
		}
		switch(res_type){
			case 'usermsg':
				msgBox.append('<div><span class="user_name" style="color:' + user_color + '">' + user_name + '</span> : <span class="user_message">' + user_message + '</span></div>');
				break;
			case 'system':
				msgBox.append('<div style="color:#bbbbbb">' + user_message + '</div>');
				break;
		}
		msgBox[0].scrollTop = msgBox[0].scrollHeight; //scroll message 

    }
	};
	
	websocket.onerror	= function(ev){ msgBox.append('<div class="system_error">Error Occurred - ' + ev.data + '</div>'); }; 
	websocket.onclose 	= function(ev){ msgBox.append('<div class="system_msg">Connection Closed</div>'); }; 

	//Message send button
	$('#send-message').click(function(){
		send_message();
	});
	
	//User hits enter key 
	$( "#message" ).on( "keydown", function( event ) {
	  if(event.which==13){
		  send_message();
	  }
	});
	
	//Send message
	function send_message(){
		var message_input = $('#message'); //user message text
		var name_input = $('#name'); //user name
		
		if(message_input.val() == ""){ //empty name?
			alert("Enter Some message Please!");
			return;
		}
		if(message_input.val() == ""){ //emtpy message?
			alert("Enter Some message Please!");
			return;
		}

		//prepare json data
		var msg = {
			message: message_input.val(),
			name: name_input.val(),
      sid : <?php echo $id ?>,
      rid : <?php echo $profile_id ?>
		};
		//convert and send data to server
		websocket.send(JSON.stringify(msg));	
		message_input.val(''); //reset message input
	}

	//create a new WebSocket object.
	
</script>
    
<?php
  $text='<script>$(document).ready(function(){ var msgBox = $("#message-box");';
       foreach($oldchats as $o){
          $text .= ' msgBox.append("<div><span class=\"user_name\">' . $o[0] . '</span> : <span class=\"user_message\">' .$o[1]. '</span></div>");';
       }
    $text .='  msgBox[0].scrollTop = msgBox[0].scrollHeight;})</script>';
 
  echo $text;
?>


