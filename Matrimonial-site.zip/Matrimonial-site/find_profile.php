<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
//print_r($_SESSION);

// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }
include('connection.php');

$id=$_SESSION['id'];

$filter='';
if(isset($_POST['filter'])){
    $filter=$_POST['filter'];
    $filter=trim($filter);
}

$query2 = "SELECT gender,fname FROM registration where id=$id";
 $result2 = mysqli_query($link, $query2);
 $row2 = mysqli_fetch_assoc($result2);
 $gender=$row2['gender'];
 $name = $row2['fname'];


$query = "SELECT personal.fname, personal.lname, personal.age,personal.pimg, professional.hedu , professional.profession,personal.resiterid
      FROM personal
      INNER JOIN professional ON personal.resiterid=professional.rid where rid!=$id AND 
       personal.gender != '$gender' AND (LOWER(CONCAT(personal.fname,' ',personal.lname)) LIKE LOWER('%$filter%'))";


$result = mysqli_query($link, $query);
//print_r($result);
 $profiles= mysqli_fetch_all($result);

//print_r($profiles);

 $test="";
$arr_length=count($profiles);
// print_r($arr_length);
// $arr_length2=count($pro);
$test .= '<div class="container row mb-2"> ';
 for($i=0;$i<$arr_length;$i++){

    $test .='
            <div class="col-lg-4">
            <div class="card" style="margin-top:20px; padding:11px; border-radius:5px; width:250px">
                <img class="card-img-top" src="profile/'.$profiles[$i][3].'" alt="Card image cap" style="width: 230px; height: 250px;"> 
                <div class="card-body">
                    <p class="card-text"> Name : '.$profiles[$i][0].' '.$profiles[$i][1].' </p>
                    <p class="card-text"> Age : '.$profiles[$i][2].' </p>
                    <p class="card-text"> Profession : '.$profiles[$i][5].' </p>
                    <p class="card-text"> Education : '.$profiles[$i][4].' </p>
                    <a href="profile.php?id='.$profiles[$i][6].'" class="btn btn-primary">Profile</a>
                </div>
            </div>
            </div>
            ';
 }
 $test .= '</div>';

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    .about{
        float: left;
        margin-right: 10px;
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #pro:hover
    {  color: black;
        text-decoration: none;
    }
   
  </style>
</head>

<body>
  <?php include('navbar.php'); ?>
  

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
    


    <div class="container" style="margin-bottom:100px">
     
        <h1 class="display-4 fw-bold text-center mb-5">Search Your Match-making Here !!</h1>

        <form class="form-inline my-2 my-lg-0 justify-content-center" action="find_profile.php" method="POST">
              <input class="form-control mr-sm-2" type="search" name="filter" placeholder="Search" aria-label="Search" style="width:350px">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search Match</button>
        </form>

       <div><?php 
            echo $test;
       ?></div> 
       
    </div>


    <section class="my-5">
        <div class="py-5">
            <h1 class="text-center">Why Choose Shaadi.com!</h1>
            <h3 class="text-center">Genuine Profiles | Safe & Secure | Detailed Family Information</h3>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-12">
                    <img src="img/w.png" class="img-fluid">
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <img class="about" src="img/a1.svg"> <h3 class="text-left info">Get Complete Family Information</h3> 
                    <p>You will find detailed family information in every profile. Knowing the family<br> 
                        will help you take the next step with confidence.</p><br>

                    <img class="about" src="img/a2.svg"> <h3 class="text-left info">Get Matches from your Community</h3> 
                    <p>With over 80 community sites, you can find a Match from your community.<br> 
                        Finding a Match based on caste and religion made easy.</p><br>

                    <img class="about" src="img/a3.svg"> <h3 class="text-left info">Enable your search without any barrier</h3> 
                    <p>Embark on your journey to find your perfect match now available in multiple <br> languages.</p><br>

                </div>
            </div>
        </div>
    </section>
    

  <div class="container mt-5">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>