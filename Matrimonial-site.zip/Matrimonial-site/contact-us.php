<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }

include('connection.php');

$id = $_SESSION['id'];

  // $query2 = "SELECT fname FROM registration where id=$id";
  // $result2 = mysqli_query($link, $query2);
  // $row2 = mysqli_fetch_assoc($result2);
  // $name=$row2['fname'];

//print_r($name);

$name = $email = $mobile = $comment = "";
$success = "";
$nameErr = $emailErr = $mobileErr = $comErr = "";

if ($_POST) {
  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }



  //String Validation  
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $profession = input_data($_POST["name"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
      $nameErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["comment"])) {
    $comErr = "Comments is required";
  } else {
    $comment = input_data($_POST["comment"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $comment)) {
        $comErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = input_data($_POST["email"]);
    // check that the e-mail address is well-formed  
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["mobile"])) {
    $mobileErr = "Mobile no is required";
  } else {
    $mobile = input_data($_POST["mobile"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $mobile)) {
      $mobileErr = "Only numeric value is allowed.";
    }
    //check mobile no length should not be less and greator than 10  
    if (strlen($mobile) != 10) {
      $mobileErr = "Mobile no must contain 10 digits.";
    }
  }

  

  if ($nameErr == "" || $emailErr == "" || $mobileErr == "" || $comErr == "") {
    $link = new mysqli("localhost", "root", "root", "matrimonial_site");
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {
      // $insertQuery = "INSERT INTO matrimonialprofile (first_name,last_name,email) VALUES ($fname,$lname,$email)";
      // $results = mysqli_query($link, $insertQuery);
      $query = $link->prepare("INSERT INTO contact (name,email,phone,comments,rid) VALUES (?,?,?,?,?)");
      $query->bind_param("ssssi", $name,$email,$mobile,$comment,$id);
      $query->execute();
      $query->close();
      $link->close();
      header('Location: contact-us.php');
    }


  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    #gender{
      margin-left: 10px
    }
    a
    {  color:white; 
        text-decoration: none;
    }
    a:hover
    {  color: white;
        text-decoration: none;
        
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro{
        color:black; 
        text-decoration: none;
        margin-left: 15px;
   }
   #pro:hover
    {  color: black;
        text-decoration: none;
    }
  </style>
</head>

<body>
  <?php include('navbar.php'); ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Contact Us</h1>
    <div class="col-lg-10 mx-auto">
        <form class="p-4 p-md-5 border rounded-3 bg-light " name="third-form" method="post">
            <div class="form-group mb-3 mt-2">
                <label for="name">Full Name</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Full Name">
                <p class="error" id="nameerr">
                    <?php echo $nameErr; ?>
                </p>
            </div>

            <div class="form-group mb-3 mt-2">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" id="email" placeholder="Email">
                <p class="error" id="emailerr">
                    <?php echo $emailErr; ?>
                </p>
            </div>

            <div class="form-group mb-3 mt-2">
                <label class="form-label" for="mobile">Phone No.</label>
                <input class="form-control" type="tel" name="mobile" id="mobile" placeholder="Phone No." maxlength="10">
                <p class="error" id="mnerr">
                  <?php echo $mobileErr; ?>
                </p>
            </div>

            <div class="mb-3">
                <label for="comment" class="form-label">Comment</label>
                <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
                <p class="error" id="comerr">
                  <?php echo $comErr; ?>
                </p>
            </div>

            <div class="d-grid gap-3 d-sm-flex justify-content-sm-center mb-5 mt-3 ">                
                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3" id="submit" name="submit"
                    value="submit">Submit</button>
            </div>

        </form>
    </div>
</div>








  <div class="container">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>