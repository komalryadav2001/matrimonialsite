-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 29, 2024 at 05:32 PM
-- Server version: 8.0.36-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matrimonial_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `rec_id` int NOT NULL,
  `msg` text NOT NULL,
  `readmsg` bit(1) NOT NULL DEFAULT b'0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `sender_id`, `rec_id`, `msg`, `readmsg`, `date`) VALUES
(1, 1, 2, 'Hello', b'1', '2024-03-19 10:05:05'),
(2, 2, 1, 'Hello', b'1', '2024-03-19 10:05:09'),
(3, 1, 3, 'hii', b'1', '2024-03-19 10:08:04'),
(4, 1, 2, 'hi', b'1', '2024-03-19 10:36:35'),
(5, 1, 2, 'hello', b'1', '2024-03-19 13:12:21'),
(6, 6, 2, 'hello', b'1', '2024-03-20 11:38:00'),
(7, 2, 6, 'hello', b'1', '2024-03-20 11:40:55'),
(8, 2, 6, 'hello', b'1', '2024-03-20 11:42:33'),
(9, 6, 2, 'hello', b'1', '2024-03-20 11:51:09'),
(10, 6, 2, 'hello', b'1', '2024-03-20 12:04:02'),
(11, 2, 6, 'hii', b'1', '2024-03-20 12:04:12'),
(12, 6, 2, 'as', b'1', '2024-03-20 12:04:19'),
(13, 2, 6, 'ert', b'1', '2024-03-20 12:04:25'),
(14, 2, 6, 'bye', b'1', '2024-03-20 12:10:18'),
(15, 6, 2, 'bye', b'1', '2024-03-20 12:10:27'),
(16, 2, 27, 'hii', b'1', '2024-03-20 13:49:56'),
(17, 38, 2, 'hello', b'1', '2024-03-21 12:48:03'),
(18, 2, 38, 'hello', b'1', '2024-03-21 12:50:22'),
(19, 38, 2, 'hii', b'1', '2024-03-21 12:50:34'),
(20, 2, 38, 'jevlis?', b'1', '2024-03-21 12:50:53'),
(21, 38, 2, 'ho', b'1', '2024-03-21 12:51:02'),
(22, 53, 2, 'hello', b'1', '2024-03-22 11:22:23'),
(23, 2, 53, 'hi', b'1', '2024-03-22 11:22:31'),
(24, 53, 2, 'what r u doing', b'1', '2024-03-22 11:22:46'),
(25, 2, 53, 'nothing', b'1', '2024-03-22 11:22:54'),
(26, 6, 2, 'hey', b'1', '2024-03-28 05:00:59'),
(27, 1, 2, 'how are you', b'1', '2024-03-28 05:01:16'),
(28, 2, 6, 'hello', b'1', '2024-03-28 05:02:42'),
(29, 2, 1, 'I\'m fine,what about you?', b'1', '2024-03-28 05:03:32'),
(30, 2, 1, 'what are you doing now?', b'1', '2024-03-28 05:04:33'),
(31, 1, 2, 'nothing', b'1', '2024-03-28 05:04:57'),
(32, 1, 2, 'hi', b'1', '2024-03-28 05:07:08'),
(33, 2, 1, 'hello', b'1', '2024-03-28 05:07:26'),
(34, 1, 2, 'hello', b'1', '2024-03-28 05:08:21'),
(35, 1, 2, 'you are free today', b'1', '2024-03-28 05:08:35'),
(36, 1, 2, 'what\'s your plan ?', b'1', '2024-03-28 05:08:48'),
(37, 1, 4, 'hey', b'1', '2024-03-28 05:20:49'),
(38, 6, 4, 'hello', b'1', '2024-03-28 05:22:40'),
(39, 1, 4, 'hey', b'1', '2024-03-28 05:56:54'),
(40, 4, 1, 'hello', b'1', '2024-03-28 05:57:15'),
(41, 6, 2, 'hey', b'1', '2024-03-28 09:52:04'),
(42, 6, 4, 'hey', b'1', '2024-03-28 09:52:29'),
(43, 4, 6, 'hello', b'1', '2024-03-28 09:53:06'),
(44, 6, 2, 'bye', b'1', '2024-03-28 10:28:35'),
(45, 6, 4, 'hello', b'1', '2024-03-28 10:37:21'),
(46, 3, 2, 'hello', b'0', '2024-03-28 11:22:19'),
(47, 1, 50, 'hii', b'1', '2024-03-28 11:29:20'),
(48, 3, 5, 'hello', b'1', '2024-03-28 11:44:51'),
(49, 5, 3, 'hi', b'1', '2024-03-28 11:45:04'),
(50, 5, 3, 'what r u doing', b'1', '2024-03-28 11:45:46'),
(51, 3, 5, 'nothing', b'1', '2024-03-28 11:45:53'),
(52, 6, 4, 'jevn zl?', b'0', '2024-03-28 12:04:57'),
(53, 50, 1, 'hello', b'1', '2024-03-28 12:15:04'),
(54, 1, 50, 'how r you', b'1', '2024-03-28 12:15:51'),
(55, 50, 1, 'fine', b'1', '2024-03-28 12:15:57'),
(56, 1, 50, 'ok bye', b'1', '2024-03-28 12:16:09'),
(57, 50, 1, 'bye', b'0', '2024-03-28 12:16:21'),
(58, 4, 57, 'hello', b'1', '2024-03-28 13:22:54'),
(59, 57, 4, 'hi', b'1', '2024-03-28 13:23:20'),
(60, 60, 3, 'hello', b'1', '2024-03-29 09:16:25'),
(61, 3, 60, 'hii', b'1', '2024-03-29 09:16:53'),
(62, 2, 1, 'hii', b'1', '2024-03-29 09:41:50'),
(63, 1, 2, 'hello', b'1', '2024-03-29 09:42:03'),
(64, 3, 4, 'hello', b'1', '2024-03-29 09:56:24'),
(65, 4, 3, 'hi', b'1', '2024-03-29 09:57:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `comments` text NOT NULL,
  `rid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `comments`, `rid`) VALUES
(1, '', 'sush@gmail.com', '8956985464', 'Such a nice experience i get from these site', 2);

-- --------------------------------------------------------

--
-- Table structure for table `frnd_request`
--

CREATE TABLE `frnd_request` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `rec_id` int NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `frnd_request`
--

INSERT INTO `frnd_request` (`id`, `sender_id`, `rec_id`, `status`) VALUES
(1, 1, 2, 'approved'),
(2, 3, 2, 'approved'),
(6, 4, 3, 'approved'),
(7, 5, 3, 'approved'),
(8, 5, 1, 'approved'),
(9, 1, 4, 'approved'),
(10, 6, 2, 'approved'),
(11, 2, 2, 'approved'),
(12, 27, 2, 'approved'),
(13, 38, 2, 'approved'),
(14, 50, 3, 'approved'),
(15, 50, 6, 'pending'),
(16, 50, 1, 'approved'),
(17, 51, 6, 'approved'),
(18, 51, 1, 'pending'),
(19, 51, 3, 'approved'),
(20, 52, 2, 'approved'),
(21, 52, 5, 'approved'),
(22, 52, 51, 'approved'),
(23, 52, 50, 'approved'),
(24, 53, 2, 'approved'),
(25, 53, 4, 'pending'),
(26, 4, 6, 'approved'),
(29, 59, 3, 'approved'),
(30, 59, 1, 'pending'),
(31, 60, 3, 'approved'),
(32, 52, 4, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `pairmaking`
--

CREATE TABLE `pairmaking` (
  `id` int NOT NULL,
  `profession` varchar(100) NOT NULL,
  `hedu` varchar(50) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `lage` varchar(20) NOT NULL,
  `klang` varchar(200) NOT NULL,
  `height` int NOT NULL,
  `rid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pairmaking`
--

INSERT INTO `pairmaking` (`id`, `profession`, `hedu`, `caste`, `religion`, `gender`, `lage`, `klang`, `height`, `rid`) VALUES
(1, 'Any', 'BE/B.Tech', 'OPEN', 'Hindu', 'Male', '20-25', 'Marathi,Hindi,English', 7, 1),
(7, 'Any', 'Any', 'OPEN', 'Any', 'Male', 'Any', 'Marathi,Hindi,English', 7, 3),
(8, 'Employee', 'BE/B.Tech', 'OPEN', 'Hindu', 'Female', '20-25', 'Marathi,Hindi', 7, 4),
(9, 'Employee', 'BE/B.Tech', 'OPEN', 'Hindu', 'Female', '20-25', 'Marathi,Hindi', 7, 4),
(10, 'Any', 'High-School', 'CHRISTIAN', 'Christian', 'Female', '26-30', 'English,Hindi', 7, 5),
(11, 'Any', 'MS', 'OPEN', 'Hindu', 'Male', '20-25', 'Marathi,Hindi', 7, 6),
(17, 'Any', 'Any', 'Any', 'Any', 'Male', 'Any', 'Marathi,Hindi', 125, 38),
(18, 'Any', 'Any', 'Any', 'Any', 'Female', 'Any', 'Any', 125, 50),
(19, 'Any', 'Any', 'Any', 'Any', 'Female', 'Any', 'Any', 125, 51),
(20, 'Any', 'Any', 'Any', 'Any', 'Male', 'Any', 'Any', 125, 52),
(21, 'Any', 'PHD', 'ST', 'Any', 'Male', 'Any', 'Any', 125, 53),
(23, 'Any', 'Any', 'ANY', 'Any', 'Male', 'Any', 'Any', 125, 57),
(24, 'Any', 'Any', 'Any', 'Any', 'Male', 'Any', 'Any', 125, 58),
(25, 'Any', 'Any', 'Any', 'Any', 'Female', 'Any', 'Any', 130, 59),
(26, 'Any', 'Any', 'Any', 'Any', 'Female', 'Any', 'Any', 125, 60);

-- --------------------------------------------------------

--
-- Table structure for table `personal`
--

CREATE TABLE `personal` (
  `id` int NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `namef` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` int NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `klang` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `age` int NOT NULL,
  `height` varchar(3) NOT NULL,
  `bgroup` varchar(10) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `zsign` varchar(50) NOT NULL,
  `mstatus` varchar(50) NOT NULL,
  `pimg` varchar(255) NOT NULL,
  `mt` varchar(50) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `hobby` varchar(200) NOT NULL,
  `resiterid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `personal`
--

INSERT INTO `personal` (`id`, `fname`, `lname`, `mname`, `namef`, `address`, `city`, `state`, `zip`, `mobile`, `email`, `gender`, `klang`, `dob`, `age`, `height`, `bgroup`, `religion`, `zsign`, `mstatus`, `pimg`, `mt`, `caste`, `hobby`, `resiterid`) VALUES
(1, 'Komal', 'Yadav', 'Sangita', 'Rajendra', 'Gargoti', 'Kolhapur', 'Maharashtra', 416209, '8975111475', 'komal@gmail.com', 'Female', 'Marathi,Hindi,English', '1999-07-15', 23, '123', 'AB-', 'Hindu', 'Aquarius', 'Single', 'pg2.jpg', 'Marathi', 'SC', 'Travelling,Singing', 1),
(9, 'Susham', 'Jagdale', 'Anaji', 'Dhanaji', 'Danoli', 'Jaysigpur', 'Punjab', 769879, '7987957657', 'sush@gmail.com', 'Male', 'Marathi,Hindi,English', '2001-06-21', 22, '154', 'B+', 'Buddhists', 'Libra', 'Single', 'pb2.jpg', 'Marathi', 'OPEN', 'Travelling,Singing', 2),
(10, 'Megha', 'Patil', 'Sejal', 'Ram', 'Yerndol', 'Ajara', 'Maharashtra', 765764, '6787744352', 'megha@gmail.com', 'Female', 'Marathi,Hindi,English', '2002-06-19', 21, '155', 'A+', 'Hindu', 'Taurus', 'Single', 'bg7.jpg', 'Marathi', 'ST', 'Dancing', 3),
(11, 'Omkar', 'Kulkarni', 'Janhvai', 'Raju', 'Nashik', 'Nashik', 'Maharashtra', 456821, '8954546534', 'omkar@gmail.com', 'Male', 'Marathi,Hindi,English,Sanskrit', '1998-07-23', 23, '145', 'AB+', 'Hindu', 'Gemini', 'Single', 'pb8.jpeg', 'Marathi', 'OPEN', 'Dancing', 4),
(13, 'Ganesh', 'Yadav', 'Madhuri', 'Ram', 'Washi', 'Panji', 'Goa', 546524, '8946481877', 'ganesh@gmail.com', 'Male', 'Marathi,Hindi', '2001-06-14', 22, '144', 'AB+', 'Christian', 'Gemini', 'Single', 'pb3.jpeg', 'Hindi', 'CHRISTIAN', 'Swimming', 5),
(14, 'Poonam', 'Mali', 'Sanjana', 'Kartik', 'shivaji nagar', 'Kolhapur', 'Maharashtra', 894565, '8954654545', 'poonam@gmail.com', 'Female', 'Marathi,Hindi', '2001-06-14', 23, '146', 'A+', 'Hindu', 'Gemini', 'Divorced', 'pg5.jpg', 'Marathi', 'OPEN', 'Swimming', 6),
(27, 'Radha', 'Lokare', 'Sejal', 'Ram', 'B-102 main road', 'Kolhapur', 'Maharashtra', 898464, '8954424524', 'rapagic960@storesr.com', 'Female', 'Marathi,Hindi', '2000-06-15', 23, '125', 'AB+', 'Hindu', 'Aries', 'Single', 'p2.jpg', 'Marathi', 'SC', 'Travelling, Singing', 38),
(28, 'Jayesh', 'Nakashe', 'sarita', 'Madhav', 'mumbai', 'Mumbai', 'Maharashtra', 546215, '8454354875', 'jayeshnakashe2002@gmail.com', 'Male', 'Marathi,Hindi', '1999-06-17', 24, '145', 'AB-', 'Buddhists', 'Taurus', 'Divorced', 'pb6.jpg', 'Marathi', 'SC', 'Swimming', 50),
(29, 'Rahul', 'Chavan', 'sunanda', 'Narayan', 'pawai lake, B-45', 'Mumbai', 'Maharashtra', 654572, '8954651465', 'rahulchavan@gmail.com', 'Male', 'Marathi,Hindi', '1997-06-12', 26, '126', 'B+', 'Buddhists', 'Cancer', 'Divorced', 'pb4.jpg', 'hindi', 'OPEN', 'Sports', 51),
(30, 'Vaibhavi', 'Pokale', 'Radhika', 'Ram', 'Shalewadi', 'Shirdi', 'Maharashtra', 165354, '9332446924', 'vaibhavi@gmail.com', 'Female', 'Marathi,Hindi', '2002-06-06', 21, '142', 'A+', 'Muslim', 'Leo', 'Widowed', 'pg6.jpg', 'Marathi', 'ST', 'Swimming', 52),
(31, 'Sanjana', 'Patil', 'Ranjana', 'Anand', 'J234- Javahar peth', 'Mumabi', 'Maharashtra', 894545, '8954654548', 'bihop15492@sentrau.com', 'Female', 'Marathi,Hindi', '2000-05-18', 23, '125', 'B+', 'Buddhists', 'Libra', 'Annulled', 'pg3.jpg', 'Marathi', 'OPEN', 'Travelling, Singing', 53),
(34, 'Sayali', 'Kulkarni', 'Pranita', 'Dhanaji', 'A-13, Warje bridge', 'Pune', 'Maharashtra', 456982, '7621549821', 'komalyadav1407@gmail.com', 'Female', 'Marathi,Hindi', '2000-06-09', 23, '153', 'AB+', 'Buddhists', 'Virgo', 'Annulled', 'pg8.jpeg', 'Hindi', 'NT', 'Swimming', 58),
(35, 'Yogesh', 'Yadav', 'Sakshi', 'Raj', 'Baner, T-7', 'Pune', 'Maharashtra', 485629, '7525458932', 'yogesh@gmail.com', 'Male', 'Marathi,Hindi', '1999-06-17', 24, '154', 'B+', 'Christian', 'Cancer', 'Single', 'pb10.jpeg', 'Hindi', 'SC', 'Travelling, Singing', 59),
(36, 'Raj', 'Powar', 'Rukama', 'Vijay', 'Rajarampuri  8th ', 'Kolhapur', 'Maharashtra', 895464, '8954654415', 'raj@gmail.com', 'Male', 'Marathi,Hindi', '2002-07-17', 21, '152', 'A-', 'Christian', 'Cancer', 'Seperated', 'pb5.jpg', 'Marathi', 'NT', 'Swimming', 60);

-- --------------------------------------------------------

--
-- Table structure for table `professional`
--

CREATE TABLE `professional` (
  `id` int NOT NULL,
  `profession` varchar(200) NOT NULL,
  `hedu` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `org` varchar(100) NOT NULL,
  `income` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `rid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `professional`
--

INSERT INTO `professional` (`id`, `profession`, `hedu`, `des`, `org`, `income`, `rid`) VALUES
(1, 'Employee', 'BE/B.Tech', 'Software Developer', 'Infosys', '5400000', 1),
(8, 'Business', 'BE/B.Tech', 'Cloth', 'Only alphabets and white space are allowed', '3200000', 2),
(9, 'Employee', 'BE/B.Tech', 'Manager', 'Wipro', '4200000', 3),
(10, 'Business', 'BE/B.Tech', 'Toy', 'Enjoy', '5200000', 4),
(11, 'Sportman', 'BE/B.Tech', 'Athletic', 'National player', '2300000', 5),
(12, 'Employee', 'MS', 'Software Developer', 'Atos', '800000', 6),
(18, 'Employee', 'PHD', 'Developer', 'Web access', '5600000', 38),
(19, 'Employee', 'BSC', 'Developer', 'Web access', '21600000', 50),
(20, 'Sportman', 'BA', 'International Player', 'Emma', '3200000', 51),
(21, 'Business', 'PHD', 'Manager', 'Isha', '520000', 52),
(22, 'Employee', 'MS', 'Manager', 'Web access', '3000000', 53),
(25, 'Lowyer', 'Masters', 'Lowyer', 'Pune High Court', '320000', 58),
(26, 'Business', 'BE/B.Tech', 'Manager', 'Yadav Groups', '21600000', 59),
(27, 'Business', 'BE/B.Tech', 'Manager', 'Emma', '3200000', 60);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `age` int NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `lname`, `address`, `city`, `state`, `gender`, `mobile`, `age`, `dob`, `email`, `password`) VALUES
(1, 'Komal', 'Yadav', 'Gargoti', 'Kolhapur', 'Maharashtra', 'Female', '8975111475', 23, '2010-01-01', 'komal@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(2, 'Susham', 'Jagdale', 'Danoli', 'Jaysigpur', 'Punjab', 'Male', '7987957657', 23, '2010-01-01', 'sush@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(3, 'Megha', 'Patil', 'Yerndol', 'Ajara', 'Maharashtra', 'Female', '6787744352', 23, '2001-01-02', 'megha@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(4, 'Omkar', 'Kulkarni', 'Nashik', 'Nashik', 'Maharashtra', 'Male', '8545672134', 22, '2001-06-14', 'omkar@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(5, 'Ganesh', 'Yadav', 'Washi', 'Panji', 'Goa', 'Male', '7585496569', 22, '2001-06-15', 'ganesh@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(6, 'Poonam', 'Mali', 'Shivaji nagar', 'Kolhapur', 'Maharashtra', 'Female', '8954654545', 23, '2001-06-14', 'poonam@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(38, 'Radha', 'Lokare', 'B-102 main road', 'Kolhapur', 'Maharashtra', 'Female', '8954424524', 23, '2000-06-15', 'rapagic960@storesr.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(50, 'Jayesh', 'Nakashe', 'Mumbai', 'Mumbai', 'Maharashtra', 'Male', '8454354875', 24, '1999-06-17', 'jayeshnakashe2002@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(51, 'Rahul', 'Chavan', 'pawai lake, B-45', 'Mumbai', 'Maharashtra', 'Male', '8954651465', 26, '1997-06-12', 'rahulchavan@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(52, 'Vaibhavi', 'Pokale', 'Shalewadi', 'Shirdi', 'Maharashtra', 'Female', '9332446924', 21, '2002-06-06', 'vaibhavi@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(53, 'Sanjana', 'Patil', 'J234- Javahar peth', 'Mumabi', 'Maharashtra', 'Female', '8954654548', 23, '2000-05-18', 'bihop15492@sentrau.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(58, 'Sayali', 'Kulkarni', 'A-13, Warje bridge', 'Pune', 'Maharashtra', 'Female', '7621549821', 23, '2000-06-09', 'sayali@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(59, 'Yogesh', 'Yadav', 'Baner, T-7', 'Pune', 'Maharashtra', 'Male', '7525458932', 23, '2000-07-11', 'yogesh@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2'),
(60, 'Raj', 'Powar', 'Rajarampuri  8th ', 'Kolhapur', 'Maharashtra', 'Male', '8954654415', 21, '2002-07-17', 'raj@gmail.com', '320d69ddf05cecf6a93785a6dde7c1d2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frnd_request`
--
ALTER TABLE `frnd_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pairmaking`
--
ALTER TABLE `pairmaking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professional`
--
ALTER TABLE `professional`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `frnd_request`
--
ALTER TABLE `frnd_request`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `pairmaking`
--
ALTER TABLE `pairmaking`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `personal`
--
ALTER TABLE `personal`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `professional`
--
ALTER TABLE `professional`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
