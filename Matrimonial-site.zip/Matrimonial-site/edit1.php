<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

include('connection.php');
// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }

$id = $_SESSION['id'];

$query3 = "SELECT fname FROM registration where id=$id";
$result3 = mysqli_query($link, $query3);
$row3 = mysqli_fetch_assoc($result3);
$name=$row3['fname'];


$query2 = "SELECT * FROM personal WHERE resiterid=$id";
$result2 = mysqli_query($link, $query2);
$row= mysqli_fetch_array($result2);   

//print_r($row);  

$fname = $lname = $mname = $namef = $email = $state = $klang = $religion = $mobile = $gender = $caste = $bdate = $city = $zip = $address1 = $age = $pimg = $mstatus = $bgroup = $height = $zsign = $mt = $hobby = $selectedBgroup = $selectedReligion = $selectedZsign = $selectedMstatus = "";
$success = "";
$fnameErr = $lnameErr = $mnameErr = $pimgErr = $klangErr = $namefErr = $bgroupErr = $relErr = $zErr = $mErr = $mtErr =  $hobbyErr = $emailErr = $bdateErr = $hErr = $ageErr = $stateErr = $mobileErr = $genderErr= $address1Err = $zipErr = $cityErr = $castErr = "";
if ($_POST) {

  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }



  //String Validation  
  if (empty($_POST["fname"])) {
    $fnameErr = "First Name is required";
  } else {
    $fname = input_data($_POST["fname"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $fname)) {
      $fnameErr = "Only alphabets and white space are allowed";
    }
  }
  if (empty($_POST["lname"])) {
    $lnameErr = "Last Name is required";
  } else {
    $lname = input_data($_POST["lname"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $lname)) {
      $lnameErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["mname"])) {
    $mnameErr = "Mother's Name is required";
  } else {
    $mname = input_data($_POST["mname"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $mname)) {
        $mnameErr = "Only alphabets and white space are allowed";
    }
  }
  if (empty($_POST["namef"])) {
    $namefErr = "Father's Name is required";
  } else {
    $namef = input_data($_POST["namef"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $namef)) {
      $namefErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["mt"])) {
    $mtErr = "Mother tongue is required";
  } else {
    $mt = input_data($_POST["mt"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $mt)) {
        $mtErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["caste"])) {
    $castErr = "Cast is required";
  } else {
    $caste = input_data($_POST["caste"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $caste)) {
      $castErr = "Only alphabets and white space are allowed";
    }
  }
  
  if (empty($_POST["city"])) {
    $cityErr = "City is required";
  } else {
    $city = input_data($_POST["city"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $city)) {
      $cityErr = "Only alphabets and white space are allowed";
    }
  }
  if (empty($_POST["address"])) {
    $address1Err = "Address is required";
  } else{
    $address1 = $_POST["address"];
  }

    if (empty($_POST["gender"])) {
        $genderErr = "Gender is required";
    } else {
        $gender = input_data($_POST["gender"]);
    }

 
  //Email Validation   
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = input_data($_POST["email"]);
    // check that the e-mail address is well-formed  
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  //Number Validation  
  if (empty($_POST["mobile"])) {
    $mobileErr = "Mobile no is required";
  } else {
    $mobile = input_data($_POST["mobile"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $mobile)) {
      $mobileErr = "Only numeric value is allowed.";
    }
    //check mobile no length should not be less and greator than 10  
    if (strlen($mobile) != 10) {
      $mobileErr = "Mobile no must contain 10 digits.";
    }
  }

  
  if (empty($_POST["bdate"])) {
    $bdateErr = "birth date is required";
  } else{
    $bdate = $_POST["bdate"];
  }

  $selectedReligion = isset($_POST['religion']) ? $_POST['religion'] : '';  
  if (isset($_POST['religion']) == false) {
    $relErr = "Please enter Religion ";
  } else {

    $select2 = $_POST['religion'];
    switch ($select2) {
      case 'Hindu':
        $religion = 'Hindu';
        break;
      case 'Muslim':
        $religion = 'Muslim';
        break;
      case 'Buddhists':
        $religion = 'Buddhists';
        break;
      case 'Christian':
        $religion = 'Christian';
        break;
      default:

        break;
    }
  }


  $selectedMstatus = isset($_POST['mstatus']) ? $_POST['mstatus'] : '';    
  if (isset($_POST['mstatus']) == false) {
    $mErr = "Please enter marital status ";
  } else {

    $select5 = $_POST['mstatus'];
    switch ($select5) {
      case 'Single':
        $mstatus = 'Single';
        break;
      case 'Divorced':
        $mstatus = 'Divorced';
        break;
      case 'Widowed':
        $mstatus = 'Widowed';
        break;
      case 'Seperated':
          $mstatus = 'Seperated';
          break;
      case 'Annulled':
            $mstatus = 'Annulled';
            break;
      default:
        break;
    }
  }

  $selectedBgroup = isset($_POST['bgroup']) ? $_POST['bgroup'] : '';    
  if (isset($_POST['bgroup']) == false) {
    $bgroupErr = "Please enter your blood group ";
  } else {
    $select4 = $_POST['bgroup'];
    switch ($select4) {
      case 'AB+':
        $bgroup = 'AB+';
        break;
      case 'AB-':
        $bgroup = 'AB-';
        break;
      case 'A-':
        $bgroup = 'A-';
        break;
      case 'A+':
        $bgroup = 'A+';
        break;
      case 'B+':
        $bgroup = 'B+';
        break;
      case 'B-':
        $bgroup = 'B-';
        break;
      case 'O+':
        $bgroup = 'O+';
        break;
      case 'O-':
        $bgroup = 'O-';
        break;
      default:

        break;
    }

  }

  if (isset($_POST['state']) == false) {
    $stateErr = "Please enter state ";
  } else {
    $select3 = $_POST['state'];
    switch ($select3) {
      case 'Maharashtra':
        $state = 'Maharashtra';
        break;
      case 'Gujrat':
        $state = 'Gujrat';
        break;
      case 'Punjab':
        $state = 'Punjab';
        break;
      case 'Tamilnadu':
        $state = 'Tamilnadu';
        break;
      case 'Rajasthan':
        $state = 'Rajasthan';
        break;
      case 'Karnataka':
        $state = 'Karnataka';
        break;
      case 'Goa':
        $state = 'Goa';
        break;
      case 'Hyderabad':
        $state = 'Hyderabad';
        break;
      case 'Bihar':
        $state = 'Bihar';
        break;
      default:

        break;
    }
  }

  

  if (empty($_POST["height"])) {
    $hErr = "Height is required";
  } else {
    $height = input_data($_POST["height"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $height)) {
      $hErr = "Only numeric value is allowed.";
    }
    if (strlen($height) != 3) {
      $hErr = "Height must contain 3 digits.";
    }
    //check mobile no length should not be less and greator than 10  
  }

  $selectedZsign = isset($_POST['zsign']) ? $_POST['zsign'] : ''; 
  if (isset($_POST['zsign']) == false) {
    $zErr = "Please enter zodiac sign ";
  } else {
    $select6 = $_POST['zsign'];
    switch ($select6) {
      case 'Aries':
        $zsign = 'Aries';
        break;
      case 'Gemini':
        $zsign = 'Gemini';
        break;
      case 'Libra':
        $zsign = 'Libra';
        break;
      case 'Taurus':
        $zsign = 'Taurus';
        break;
      case 'Aquarius':
        $zsign = 'Aquarius';
        break;
      case 'Cancer':
        $zsign = 'Cancer';
        break;
      case 'Leo':
        $zsign = 'Leo';
        break;
      case 'Virgo':
        $zsign = 'Virgo';
        break;
      case 'Caprocorn':
        $zsign = 'Caprocorn';
        break;
      case 'Pisces':
        $zsign = 'Pisces';
        break;
      case 'Sigittarius':
        $zsign = 'Sigittarius';
        break;
      case 'Scorpio':
        $zsign = 'Scorpio';
        break;
      default:

        break;
    }
  }

  if (empty($_POST["klang"])) {
    $klangErr = "languages known is required";
  } else {
    $klang = input_data($_POST["klang"]);
    // check if name only contains letters and whitespace  '/^[a-zA-Z\s\,]+$/' 
    if (!preg_match("/^[a-zA-Z\s\,]*$/", $klang)) {
        $klangErr = "Only alphabets and white space are allowed";
    }
  }


  if (empty($_POST["zip"])) {
    $zipErr = "Zip is required";
  } else {
    $zip = input_data($_POST["zip"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $zip)) {
      $ZipErr = "Only numeric value is allowed.";
    }
    //check mobile no length should not be less and greator than 10  
    if (strlen($zip) != 6) {
      $zipErr = "Zip must contain 6 digits.";
    }
  }

  $hobby = $_POST['hobby'];
  $age= $_POST['age'];
    
  if (isset($_POST['next'])) {
    // print_r($_FILES);
    
       $filename = $_FILES["pimg"]['name'];
       $tempname = $_FILES["pimg"]["tmp_name"];
       $folder = "profile/" . $filename;
       $allowed = array('jpeg', 'jpg', 'png', 'JPEG', 'JPG', 'PNG');
       //$ext = pathinfo($filename, PATHINFO_EXTENSION);
       move_uploaded_file($tempname, "profile/" . $filename);
       $pimg=$filename;
         // if (move_uploaded_file($filename, "../profile/" . $filename)) {
         //   $pimg = $folder;
         //   $success = "Image uploaded successfully!";
         // } else {
         //   //print_r($filename);
         //   $pimgErr = "Failed to upload image!";
         // }
       
     
 
   }


  if ($fnameErr == "" && $lnameErr == "" && $mnameErr == ""  && $namefErr == "" && $address1Err == ""  && $cityErr == ""  && $stateErr == "" && $zipErr == "" && $mobileErr == "" && $emailErr == "" && $genderErr == "" && $pimgErr == "" && $klangErr == "" && $bdateErr == "" && $ageErr == "" && $hErr == "" && $bgroupErr == "" && $relErr == "" && $zErr == ""  && $mErr == "" && $mtErr == "" && $castErr == "") {   

   // $link = new mysqli("localhost", "root", "root", "matrimonial_site");
   include('connection.php');
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {      
      // $id = $_SESSION['id'];
      if(!empty($pimg)){
        $query = $link->prepare("UPDATE personal SET fname=?,lname=?,mname=?,namef=?,address=?,city=?,state=?,zip=?,mobile=?,email=?,gender=?,klang=?,dob=?,age=?,height=?,bgroup=?,religion=?,zsign=?,mstatus=?,pimg=?,mt=?,caste=?,hobby=? WHERE resiterid=$id");
        $query->bind_param("sssssssisssssisssssssss", $fname, $lname, $mname, $namef, $address1, $city, $state, $zip, $mobile, $email, $gender, $klang, $bdate, $age, $height, $bgroup, $religion, $zsign, $mstatus, $pimg, $mt, $caste, $hobby);
        $query->execute();
        $query->close();
        $link->close();
  
      }else{
        $query = $link->prepare("UPDATE personal SET fname=?,lname=?,mname=?,namef=?,address=?,city=?,state=?,zip=?,mobile=?,email=?,gender=?,klang=?,dob=?,age=?,height=?,bgroup=?,religion=?,zsign=?,mstatus=?,mt=?,caste=?,hobby=? WHERE resiterid=$id");
        $query->bind_param("sssssssisssssissssssss", $fname, $lname, $mname, $namef, $address1, $city, $state, $zip, $mobile, $email, $gender, $klang, $bdate, $age, $height, $bgroup, $religion, $zsign, $mstatus, $mt, $caste, $hobby);
        $query->execute();
        $query->close();
        $link->close();
      }
     

      header('Location: edit2.php');
    }
  }



}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    #gender{
      margin-left: 10px
    }
    a
    {  color:white; 
      text-decoration: none;
    }

    a:hover
    {  color: white; 
      text-decoration: none;
    }
  
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro{
        color:black; 
        text-decoration: none;
        margin-left: 15px;
   }
   #pro:hover
    {  color: black;
        text-decoration: none;
    }
    
  </style>
</head>

<body>
<?php include('navbar.php'); ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
              <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
              <div class="carousel-caption d-none d-md-block">
                  <h3>Someone Somewhere is Dreaming of You</h3>
              </div>
            </div>
            <div class="carousel-item" id="#c2">
              <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
              <div class="carousel-caption d-none d-md-block">
                    <h3>Love must be as much a light as it is a flame </h3>
                </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
              <div class="carousel-caption d-none d-md-block">
                    <h3>Two hearts in love need no words</h3>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Personal Information</h1>
    <div class="col-lg-10 mx-auto">
        <form class="p-4 p-md-5 border rounded-3 bg-light " name="first-form" method="post" enctype="multipart/form-data">
        
        <div class="row mb-2 ">
            <div class="col-lg-6">
                <label class="form-label " for="fname">First Name</label>
                <input class="form-control " name="fname" id="fname" aria-describedby="namePrepend" type="text"
                placeholder="First Name" value="<?php echo ucfirst($row[1]);?>"> 
                <p class="error" id="fnerr">
                <?php echo $fnameErr; ?>
                </p>
            </div>
            <div class="col-lg-6">
                <label class="form-label " for="lname">Last Name</label>
                <input class="form-control " name="lname" id="lname" type="text" placeholder="Last Name" value="<?php echo $row[2]?>">
                <p class="error" id="lnerr">
                <?php echo $lnameErr; ?>
                </p>
            </div>
            </div>
            
            <div class="row mb-2 ">
            <div class="col-lg-6 ">
                <label class="form-label " for="mname">Mother's Name</label>
                <input class="form-control " name="mname" id="mname" aria-describedby="namePrepend" type="text"
                placeholder="Mother's Name" value="<?php echo $row[3]?>">
                <p class="error" id="mnerr">
                <?php echo $mnameErr; ?>
                </p>
            </div>
            <div class="col-lg-6">
                <label class="form-label " for="namef">Father's Name</label>
                <input class="form-control " name="namef" id="namef" type="text" placeholder="Father's Name" value="<?php echo $row[4]?>">
                <p class="error" id="nferr" >
                <?php echo $namefErr; ?>
                </p>
            </div>
            </div>

            <div class="form-group mb-3 mt-2">
                <label for="inputAddress">Address</label>
                <input type="text" class="form-control" name="address" id="inputAddress" placeholder="Address" value="<?php echo $row[5]?>">
                <p class="error" id="add1err" >
                    <?php echo $address1Err; ?>
                </p>
            </div>


        <div class="row">
          <div class="col-lg-5 mb-3 mt-2">
            <div class="form-row">
              <div class="form-group ">
                <label for="inputCity">City</label>
                <input type="text" class="form-control" name="city" id="inputCity" placeholder="Enter City" value="<?php echo $row[6]?>">
                <p class="error" id="cityerr">
                  <?php echo $cityErr; ?>
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-3 mt-2">
          <div class="form-group">
                        <div><label class="form-label" for="state">State </label></div>
                        <select name="state" class="form-select p-1"  style="width:250px; height:39px;">
                        <option selected disabled>Select State</option>
                            <option value="Maharashtra" <?php if($row[7]=="Maharashtra") echo 'selected="selected"'; ?>>Maharashtra</option>
                            <option value="Gujrat" <?php if($row[7]=="Gujrat") echo 'selected="selected"'; ?>>Gujrat</option>
                            <option value="Punjab" <?php if($row[7]=="Punjab") echo 'selected="selected"'; ?>>Punjab</option>
                            <option value="Tamilnadu" <?php if($row[7]=="Tamilnadu") echo 'selected="selected"'; ?>>Tamilnadu</option>
                            <option value="Rajasthan" <?php if($row[7]=="Rajasthan") echo 'selected="selected"'; ?>>Rajasthan</option>
                            <option value="Karnataka" <?php if($row[7]=="Karnataka") echo 'selected="selected"'; ?>>Karnataka</option>
                            <option value="Goa" <?php if($row[7]=="Goa") echo 'selected="selected"'; ?>>Goa</option>
                            <option value="Hyderabad" <?php if($row[7]=="Hyderabad") echo 'selected="selected"'; ?>>Hyderabad</option>
                            <option value="Bihar" <?php if($row[7]=="Bihar") echo 'selected="selected"'; ?>>Bihar</option>
                        </select>
                        <p class="error" id="stateerr">
                            <?php echo $stateErr; ?>
                        </p>
                    </div>
          </div>
          <div class="col-lg-3 mb-3 mt-2">
            <div class="form-group ">
              <label for="inputZip">Zip</label>
              <input type="number" class="form-control" name="zip" id="inputZip" placeholder="Pincode" onKeyPress="if(this.value.length==6) return false;" value="<?php echo $row[8] ?>">
              <p class="error" id="ziperr">
                <?php echo $zipErr; ?>
              </p>
            </div>
          </div>
        </div>
        
        <div class="row">
            <div class="col-lg-6 ">
                <label class="form-label" for="mobile">Phone No.</label>
                <input class="form-control" type="tel" name="mobile" id="mobile" placeholder="Phone No." maxlength="10" value="<?php echo $row[9] ?>">
                <p class="error" id="mnerr">
                <?php echo $mobileErr; ?>
                </p>
            </div>

            <div class="col-lg-6 ">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" name="email" id="email" type="email" placeholder="Email" value="<?php echo $row[10] ?>">
                <p class="error" id="mlerr">
                <?php echo $emailErr; ?>
                </p>
            </div>
        </div>


        <div class="row" id="gender">
            <div class="col-lg-6 form-floating mb-3 p-2">

                <div class="row"><label for="inputState" class="form-label text-lg-start">Gender 
                        </label></div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="male" value="Male" <?php if($row && $row[11]=="Male"){ echo 'checked="checked"'; } ?>>
                        <label class="form-check-label" for="flexRadioDefault1">
                            Male
                        </label>
                </div>
                <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="Female" <?php if($row && $row[11]=="Female"){ echo 'checked="checked"'; } ?>>
                        <label class="form-check-label" for="flexRadioDefault2">
                            Female
                        </label>
                </div>
                <span class="error"> <?php echo $genderErr;?></span>

            </div>


            <div class="form-floating mb-3 col-lg-6 p-1">
                <!-- <div class="col-lg-6 form-floating mb-3 p-1"> -->
                  <div class="form-group ">
                    <label for="klang">Known Languages</label>
                    <input type="text" class="form-control" name="klang" id="klang" placeholder="Enter known languages" value="<?php echo $row[12] ?>">
                    <p class="error" id="klangerr">
                      <?php echo $klangErr; ?>
                    </p>
                  </div>
                <!-- </div> -->

            </div>
        </div>

        <div class="row">
          <div class="col-lg-5 mb-3 mt-2">
            <div class="ddate mb-3">
                    <label for="bdate" class="form-label">Birth Date</label>
                    <input class="form-control" type="date" name="bdate" id="mybdate" width="900px" max='2010-01-01' value="<?php echo $row[13] ?>" onchange="calculateAge()">
                    <p class="error" id="bdate">
                            <?php echo $bdateErr; ?>
                    </p>
            </div>
          </div>
          <div class="col-lg-4 mb-3 mt-2">
            <div class="form-group ">
                      <label for="age">Age</label>
                        <input type="number" class="form-control" name="age" id="age" placeholder="Age" onKeyPress="if(this.value.length==2) return false;" value="<?php if(!empty('age')){ echo $row[14]; }?>">      
                    <!-- <div id="age"></div> -->
            </div>
          </div>
          <div class="col-lg-3 mb-3 mt-2">
            <div class="form-group ">
              <label for="height">Height(in cm)</label>
              <input type="number" class="form-control" name="height" id="height" placeholder="height(in cm)" onKeyPress="if(this.value.length==4) return false;" value="<?php echo $row[15] ?>">
              <p class="error" id="herr">
                <?php echo $hErr; ?>
              </p>
            </div>
          </div>
        </div>


        <div class="row">
            <div class="input-group mb-3 mt-3 col-lg-3">
            <div><label class="form-label " for="bgroup">Blood Group </label></div>
              <select class="form-select myopt  p-1" name="bgroup" id="bgroup" style="width:200px; height:39px;">
                <option value="" disabled selected>Select Any</option>
                <option value="AB+" <?php if($row[16]=="AB+") echo 'selected="selected"'; ?>>AB+</option>
                <option value="AB-" <?php if($row[16]=="AB-") echo 'selected="selected"'; ?>>AB-</option>
                <option value="A+" <?php if($row[16]=="A+") echo 'selected="selected"'; ?>>A+</option>
                <option value="A-" <?php if($row[16]=="A-") echo 'selected="selected"'; ?>>A-</option>
                <option value="B+" <?php if($row[16]=="B+") echo 'selected="selected"'; ?>>B+</option>
                <option value="B-" <?php if($row[16]=="B-") echo 'selected="selected"'; ?>>B-</option>
                <option value="O+" <?php if($row[16]=="O+") echo 'selected="selected"'; ?>>O+</option>
                <option value="O-" <?php if($row[16]=="O-") echo 'selected="selected"'; ?>>O-</option>
              </select>
              <p class="error" id="bgrouperr">
                <?php echo $bgroupErr; ?>
              </p>
            </div>

            <div class="input-group mb-3 mt-3 col-lg-3">
            <label class="form-label" for="religion">Religion</label>
              <select class="form-select myopt1 p-1" name="religion" id="religion" style="width:200px; height:39px;">
                <option value="" disabled selected>Select Any</option>
                <option value="Hindu" <?php if($row[17]=="Hindu") echo 'selected="selected"'; ?>> Hindu</option>
                <option value="Muslim" <?php if($row[17]=="Muslim") echo 'selected="selected"'; ?>> Muslim</option>
                <option value="Buddhists" <?php if($row[17]=="Buddhists") echo 'selected="selected"'; ?>> Buddhists</option>
                <option value="Christian" <?php if($row[17]=="Christian") echo 'selected="selected"'; ?>> Christian</option>
              </select>
              <p class="error" id="relerr">
                <?php echo $relErr; ?>
              </p>
            </div>
            
            <div class="input-group mb-3 mt-3 col-lg-3">
            <label class="form-label" for="zsign">zodiac signs</label>
              <select class="form-select myopt2 p-1" name="zsign" id="zsign" style="width:200px; height:39px;">
                <option value="" disabled selected>Select Any</option>
                <option value="Aries" <?php if($row[18]=="Aries") echo 'selected="selected"'; ?>>Aries</option>
                <option value="Gemini" <?php if($row[18]=="Gemini") echo 'selected="selected"'; ?>>Gemini</option>
                <option value="Libra" <?php if($row[18]=="Libra") echo 'selected="selected"'; ?>>Libra</option>
                <option value="Taurus" <?php if($row[18]=="Taurus") echo 'selected="selected"'; ?>>Taurus</option>
                <option value="Aquarius" <?php if($row[18]=="Aquarius") echo 'selected="selected"'; ?>>Aquarius</option>
                <option value="Cancer" <?php if($row[18]=="Cancer") echo 'selected="selected"'; ?>>Cancer</option>
                <option value="Leo" <?php if($row[18]=="Leo") echo 'selected="selected"'; ?>>Leo</option>
                <option value="Virgo" <?php if($row[18]=="Virgo") echo 'selected="selected"'; ?>>Virgo</option>
                <option value="Caprocorn" <?php if($row[18]=="Caprocorn") echo 'selected="selected"'; ?>>Caprocorn</option>
                <option value="Pisces" <?php if($row[18]=="Pisces") echo 'selected="selected"'; ?>>Pisces</option>
                <option value="Sagittarius" <?php if($row[18]=="Sagittarius") echo 'selected="selected"'; ?>>Sagittarius</option>
                <option value="Scorpio" <?php if($row[18]=="Scorpio") echo 'selected="selected"'; ?>>Scorpio</option>
              </select>
              <p class="error" id="zerr">
                <?php echo $zErr; ?>
              </p>
            </div>

            <div class="input-group mb-3 mt-3 col-lg-3">
            <label class="form-label" for="mstatus">Marital Status</label>
              <select class="form-select myopt p-1" name="mstatus" id="mstatus" style="width:200px; height:39px;">
                <option value="" disabled selected>Select Any</option>
                <option value="Single" <?php if($row[19]=="Single") echo 'selected="selected"'; ?>>Single</option>
                <option value="Divorced" <?php if($row[19]=="Divorced") echo 'selected="selected"'; ?>>Divorced</option>
                <option value="Widowed" <?php if($row[19]=="Widowed") echo 'selected="selected"'; ?>>Widowed</option>
                <option value="Seperated" <?php if($row[19]=="Seperated") echo 'selected="selected"'; ?>>Seperated</option>
                <option value="Annulled" <?php if($row[19]=="Annulled") echo 'selected="selected"'; ?>>Annulled</option>
              </select>
              <p class="error" id="merr">
                <?php echo $mErr; ?>
              </p>
            </div>
        </div>


        <div class="row mb-2 ">
            <div class="input-group mb-3 mt-3 col-lg-4">
            <label for="idCard">Profile Image</label>
                <input type="file" class="form-control-file" name="pimg" id="pimg" >
                <p class="error" id="pimg">
                  <?php echo $pimgErr; ?>
                </p>
            </div>
            <div class="col-lg-4 mt-3">
                <label class="form-label " for="mt">Mother Tongue</label>
                <input class="form-control " name="mt" id="namef" type="text" placeholder="eg. Marathi" value="<?php echo $row[21] ?>">
                <p class="error" id="mterr">
                <?php echo $mtErr; ?>
                </p>
            </div>
            <div class="col-lg-4 mt-3">
                <label class="form-label " for="caste">Caste</label>
                <input class="form-control " name="caste" id="caste" type="text" placeholder="Caste" value="<?php echo $row[22] ?>">
                <p class="error" id="casteerr">
                <?php echo $castErr; ?>
                </p>
            </div>
        </div>



            <div class="form-group mb-3 mt-2">
                <label for="hobby">Hobby</label>
                <input type="text" class="form-control" name="hobby" id="hobby" placeholder="eg. Travelling" value="<?php echo $row[23] ?>">
                <p class="error" id="hobbyerr">
                    <?php echo $hobbyErr; ?>
                </p>
            </div>

              
            <div class="d-grid gap-3 d-sm-flex justify-content-sm-center mb-5 mt-3 ">
              
              <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3" id="submit" name="next"
                    value="Next">Next
                    <!-- <a href="sec-form.php"> Next </a> -->
                </button>
              
              
            </div>

        </form>
    </div>
</div>








  <div class="container">
    <div class="row mx-5 pl-5 ">
      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script>
       function calculateAge() {
            // Get the selected birthdate from the input
            var dob = document.getElementById("mybdate").value;

            // Split the date string into year, month, and day
            var parts = dob.split("-");
            var year = parseInt(parts[0], 10);
            var month = parseInt(parts[1], 10);
            var day = parseInt(parts[2], 10);

            // Get today's date
            var today = new Date();

            // Calculate age
            var age = today.getFullYear() - year;
            var m = today.getMonth() + 1 - month;
            if (m < 0 || (m === 0 && today.getDate() < day)) {
                age--;
            }

            // Display the age
            var input = document.getElementById("age");
            input.value = age;
        }
</script>

</body>


</html>