<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

include('connection.php');
// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }

$id = $_SESSION['id'];

$query3 = "SELECT fname FROM registration where id=$id";
$result3 = mysqli_query($link, $query3);
$row3 = mysqli_fetch_assoc($result3);
$name=$row3['fname'];

$profession = $hedu = $des = $org = $myincome = "";
$success = "";
$proErr = $heduErr = $desErr = $orgErr = $myincomeErr = "";

if ($_POST) {
  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }



  //String Validation  
  if (empty($_POST["profession"])) {
    $proErr = "Profession is required";
  } else {
    $profession = input_data($_POST["profession"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $profession)) {
      $proErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["des"])) {
    $desErr = "Designation is required";
  } else {
    $des = input_data($_POST["des"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $desErr)) {
      $desErr = "Only alphabets and white space are allowed";
    }
  }

  if (empty($_POST["org"])) {
    $orgErr = "Organization name is required";
  } else {
    $org = input_data($_POST["org"]);
    // check if name only contains letters and whitespace  
    if (!preg_match("/^[a-zA-Z ]*$/", $org)) {
      $org = "Only alphabets and white space are allowed";
    }
  }

  //Number Validation  
  if (empty($_POST["myincome"])) {
    $myincomeErr = "Income is required";
  } else {
    $myincome = input_data($_POST["myincome"]);
    // check if mobile no is well-formed  
    if (!preg_match("/^[0-9]*$/", $myincome)) {
      $myincomeErr = "Only numeric value is allowed.";
    }
  }

  if (isset($_POST['hedu']) == false) {
    $heduErr = "Please enter Education ";
  } else {

    $select = $_POST['hedu'];
    switch ($select) {
      case 'High-School':
        $hedu = 'High-School';
        break;
      case 'Diploma':
        $hedu = 'Diploma';
        break;
      case 'BE/B.Tech':
        $hedu = 'BE/B.Tech';
        break;
      case 'PHD':
            $hedu = 'PHD';
            break;
      case 'Masters':
            $hedu = 'Masters';
            break;
      case 'BA':
            $hedu = 'BA';
            break;
      case 'BSC':
            $hedu = 'BSC';
            break;
      case 'MS':
            $hedu = 'MS';
            break;
      default:

        break;
    }
  }

  if ($proErr == "" && $heduErr == "" && $desErr == "" && $myincomeErr == "" && $orgErr=="") {
    //$link = new mysqli("localhost", "root", "root", "matrimonial_site");
    include('connection.php');
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {
      // $id = $_SESSION['id'];
      $query = $link->prepare("INSERT INTO professional(profession,hedu,des,org,income,rid) VALUES (?,?,?,?,?,?)");
      $query->bind_param("sssssi", $profession,$hedu,$des,$org,$myincome,$id);
      $query->execute();
      $query->close();
      $link->close();

      header('Location: third-form.php');
    }


  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    a
    {  color:white;  
        text-decoration: none;
    }

    a:hover
    {  color: white; 
        text-decoration: none;
    }
    #all{
      color:red;
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro{
        color:black; 
        text-decoration: none;
        margin-left: 15px;
   }
   #pro:hover
    {  color: black;
        text-decoration: none;
    }
  </style>
</head>

<body>
<?php include('navbar.php'); ?>

  

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Professional Information</h1>
    <div class="col-lg-10 mx-auto">
        <form class="p-4 p-md-5 border rounded-3 bg-light " name="sec-form" method="post">
        <p id="all"><b>All Fields are mandetory to fill*</b></p>
        <div class="row mb-2 ">
            <div class="col-lg-6 ">
                <label class="form-label" for="profession">Profession</label>
                <input class="form-control" type="tel" name="profession" id="profession" placeholder="Profession" value="<?php echo $profession ?>">
                <p class="error" id="proerr">
                <?php echo $proErr; ?>
                </p>
            </div>
            <div class="col-lg-6">
                <div class="form-group">                           
                <div><label class="form-label" for="hedu">Highest Education </label></div>
                    <select class="form-select myopt1 p-1" name="hedu" id="hedu" style="width:280px; height:38px;">
                        <option selected disabled>Choose...</option>
                        <option value="High-School">High School(12th)</option>
                        <option value="Diploma">Diploma</option>
                        <option value="BE/B.Tech">BE/B.Tech</option>
                        <option value="PHD">PHD</option>
                        <option value="Masters">Masters</option>
                        <option value="BA">BA(Bachelor of Arts)</option>
                        <option value="BSC">BSC</option>
                        <option value="MS">MS</option>
                    </select>
                    <p class="error" id="heduerr">
                        <?php echo $heduErr; ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="row mb-2 ">
            <div class="col-lg-6">
                <label class="form-label " for="des">Designation</label>
                <input class="form-control " name="des" id="des" type="text"
                placeholder="Designation" value="<?php echo $des ?>">
                <p class="error" id="deserr">
                <?php echo $desErr; ?>
                </p>
            </div>
            <div class="col-lg-6 ">
                <label class="form-label " for="org">Organization Name : </label>
                <input class="form-control " name="org" id="org" type="text" placeholder="Organization" value="<?php echo $org ?>">
                <p class="error" id="orgerr">
                <?php echo $orgErr; ?>
                </p>
            </div>
        </div>


        <div class="row mb-2 ">
            <div class="col-lg-6">
                <label class="form-label " for="myincome">Income (INR)</label>
                <input class="form-control " name="myincome" id="myincome" type="text"
                placeholder="Income" value="<?php echo $myincome ?>">
                <p class="error" id="myincomerr">
                <?php echo $myincomeErr; ?>
                </p>
            </div>
            
        </div>

        


        
               

            
            <div class="d-grid gap-3 d-sm-flex justify-content-sm-center mb-5 mt-3 ">
                <!-- <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 mr-5" id="submit" name="Previous"
                    value="Previous">Previous</button> -->
                <!-- <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3" id="submit" name="next"
                    value="Next"> <a href="third-form.php"> Next</a></button> -->

                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 mr-5" id="submit" name="previous"
                    value="Previous">
                    <a href="first-form.php"> Previous </a>
                </button>


                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3" id="submit" name="next"
                    value="Next">Next
                    <!-- <a href="third-form.php">  </a> -->
                </button>
              
            </div>

        </form>
    </div>
</div>


  <div class="container">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>