<?php
$link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
if (mysqli_connect_error()) {
  die("There was error something while connecting.");
}

?>