<?php
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  session_start();
  
  // $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
  // if (mysqli_connect_error()) {
  //   die("There was error something while connecting.");
  // }
  
  include('connection.php');
  

if(isset($_GET['sid']) && isset($_GET['rid'])){
    $rid=$_GET['rid']; 
    $sid=$_GET['sid']; 
    $query = $link->prepare("UPDATE chats SET readmsg=1 where (rec_id=? AND sender_id=? AND readmsg=0)");
           
    $query->bind_param("ii", $rid,$sid);

     $query->execute();
     $query->close();
     $link->close();

     if(isset($_GET['redirect']) && $_GET['redirect'] == true){
        header('Location: profile.php?id='.$sid.'&start_chat=true');
    }
     
}



?>