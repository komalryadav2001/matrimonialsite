<?php  
  error_reporting(E_ALL);
  ini_set('display_errors', '1');

  
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
</head>

<body>

        <div>
            <img class="d-block" src="img/img1.webp" alt="First slide" style="height:300px; width: 100%; object-fit:cover;">
        </div>
        
        <div class="mt-5">
          <h1>Welcome to Shaadi.com</h1>
          <p>We believe choosing a life partner is a big and important decision, and hence work towards giving a simple and secure matchmaking experience for you and your family. Each profile registered with us goes through a manual screening process before going live on site; we provide superior privacy controls for Free; and also verify contact information of members.</p>
        </div>

        <div class="mt-5 mb-5">
          <h3 class="mt-5">Login Details from Shaadi.com</h3>
          <p>Email : komal@gmail.com</p>
          <p>Password : Password@2001 </p>
        </div>
        


  <footer class="bg-dark text-secondary text-center p-5 mt-2" style="width: 100%; height: 200px;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
  </footer>


</body>

</html>