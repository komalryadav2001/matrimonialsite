<?php
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  session_start();
  
  // $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
  // if (mysqli_connect_error()) {
  //   die("There was error something while connecting.");
  // }
  
  include('connection.php');
  
  $id = $_SESSION['id'];

  $profile_id=$_GET['id']; 

  $status='pending';
if(isset($_GET['status'])){
    $status='approved';
    $query = $link->prepare("UPDATE frnd_request SET status=? where (rec_id=? AND sender_id=?)");
           
    $query->bind_param("sii", $status,$id,$profile_id);

     $query->execute();
     $query->close();
     $link->close();
     
}else{
  $query = $link->prepare("INSERT INTO frnd_request(sender_id,rec_id,status) VALUES (?,?,?)");
           
    $query->bind_param("iis", $id,$profile_id,$status);

     $query->execute();
     $query->close();
     $link->close();
}
header('Location: profile.php?id='.$profile_id);
?>