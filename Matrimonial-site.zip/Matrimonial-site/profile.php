<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }

include('connection.php');

$id = $_SESSION['id'];


$query3 = "SELECT fname FROM registration where id=$id";
$result3 = mysqli_query($link, $query3);
$row3 = mysqli_fetch_assoc($result3);
$name=$row3['fname'];


$profile_id=$_GET['id'];  
$query = "SELECT personal.fname, personal.lname, personal.age,personal.gender, personal.address, personal.city,personal.state, personal.height, personal.caste,personal.religion, personal.pimg,personal.mstatus, personal.klang,personal.hobby, professional.hedu , professional.profession FROM personal INNER JOIN professional ON personal.resiterid=professional.rid where personal.resiterid=$profile_id";
$result = mysqli_query($link, $query);
$row= mysqli_fetch_assoc($result);

$query = "SELECT status from frnd_request where (rec_id=$profile_id AND sender_id=$id) OR (rec_id=$id AND sender_id=$profile_id)";
$result = mysqli_query($link, $query);
$status= mysqli_fetch_assoc($result);

//print_r($id);
 //print_r($row);
// print_r($row2);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    .about{
        float: left;
        margin-right: 10px;
    }

    #proimg{
      height: 300px;
      width: 250px;
    }

    #req{
      color:white;
      text-decoration:none;
    }
    #req:hover{
      color:white;
      text-decoration:none;
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #pro:hover
    {  color: black;
        text-decoration: none;
    } 
   
  </style>
</head>

<body>

  <script>
    function markRead(sid,rid){
          $.ajax({

        // Our sample url to make request

        url:

            'http://192.168.2.73/Matrimonial-site/readmsg.php?rid='+rid+'&sid='+sid+'',

        // Type of Request

        type: "GET",

        

        success: function (data) {


        },


        error: function (error) {

            console.log(error);

        }

        });
    }
  </script>

  <?php include('navbar.php'); ?>
  

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
   


    <div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Profile Details</h1>
    <div class="col-lg-10 mx-auto col-md-4 d-flex justify-content-center ">
        <form class="p-4 p-md-5 border rounded-3 bg-light col-sm-9" name="registration-form" method="post">


            <div class="row mb-2 ">
                <div class="col-lg-6">
                   <img id="proimg" src="profile/<?php echo $row['pimg']; ?>" alt="">
                </div>
                <div class="col-lg-6">
                    <label class="form-label " for="fullName">Name : <?php echo $row['fname'],' ', $row['lname']; ?></label><br>

                    <label class="form-label " for="Address">Gender : <?php echo $row['gender']; ?></label><br>

                    <label class="form-label " for="Address">Address : <?php echo $row['address'], ', ',$row['city']; ?></label><br>

                    <label class="form-label " for="state">State : <?php echo $row['state']; ?></label><br>

                    <label class="form-label " for="profession">Profession : <?php echo $row['profession']; ?></label><br>

                    <label class="form-label " for="education">Education : <?php echo $row['hedu']; ?></label><br>

                    <label class="form-label " for="age">Age : <?php echo $row['age']; ?></label><br>

                    <label class="form-label " for="religition">Religion : <?php echo $row['religion']; ?></label><br>

                    <label class="form-label " for="caste">Caste : <?php echo $row['caste']; ?></label><br>

                    <label class="form-label " for="height">Height : <?php echo $row['height']; ?></label><br>

                    <label class="form-label " for="mstatus">Marital Status : <?php echo $row['mstatus']; ?></label><br>
                    
                    <label class="form-label " for="klang">Known Languages : <?php echo $row['klang']; ?></label><br>

                    <label class="form-label " for="hobby">Hobby : <?php echo $row['hobby']; ?></label><br>

                </div>
            </div> 

            <div class="text-center">
            <?php 
              if(empty($status)){
               echo '<button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text" id="request" name="request"
                    value="Request"> 
                     <a id="req" href="request.php?id='.$profile_id.'"> Request </a>
                </button>';
              }
              else if($status['status'] == "pending"){
                echo '<button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text" id="request" name="request"
                value="Request Sent" disabled> Request Sent</button>';
              }
              else if($status['status'] == "approved"){
                echo ' <button onclick="document.getElementsByClassName(\'msger\')[0].style.display=\'block\';" type="button" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text ml-3" id="chat" name="chat"
                value="Chat">Start Chat</button> ';
               
              }

               ?> 

               
                      

              </div>
        </form>
    </div>
</div>

    

  <div class="container mt-5">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>




  <?php include('chatbot.php'); 
     if($status['status'] == "approved" && isset($_GET['start_chat']) && $_GET['start_chat'] == true){
      echo '<script>document.getElementsByClassName(\'msger\')[0].style.display=\'block\'; $(document).ready(function(){console.log("Message")})</script>';
    }

  ?>

</script>
</body>

</html>