<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
include('connection.php');
// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }

$id = $_SESSION['id'];

$query3 = "SELECT fname FROM registration where id=$id";
$result3 = mysqli_query($link, $query3);
$row3 = mysqli_fetch_assoc($result3);
$name=$row3['fname'];

$profession = $hedu = $caste = $religion = $gender = $agel = $klang = $height = "";
$success = "";
$proErr = $heduErr = $casteErr = $relErr = $genderErr = $agelErr = $klangErr = $hErr = "";

if ($_POST) {
  function input_data($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }


  if (empty($_POST["profession"])) {
    $profession=$_POST["profession"]="Any";
  } else {
    $profession =$_POST["profession"];

  }

  if (empty($_POST["caste"])) {
    $caste=$_POST["caste"]="Any";
  } else {
    $caste = $_POST["caste"];
  }

  if (empty($_POST["klang"])) {
    $klang=$_POST["klang"]="Any";
  } else {
    $klang = $_POST["klang"];
  }

  if (empty($_POST["height"])) {
    $height=$_POST["height"]="125";
  } else {
    $height = $_POST["height"];
  }

  if (empty($_POST["religion"])) {
    $religion=$_POST["religion"]="Any";
  } else {
    $religion =$_POST["religion"];

  }

  // if (isset($_POST['religion']) == false) {
  //   $religion = 'any';
  // } else {
  //   $select2 = $_POST['religion'];
  //   switch ($select2) {
  //     case 'hindu':
  //       $religion = 'hindu';
  //       break;
  //     case 'muslim':
  //       $religion = 'muslim';
  //       break;
  //     case 'buddhists':
  //       $religion = 'buddhists';
  //       break;
  //     case 'christian':
  //       $religion = 'christian';
  //       break;
  //     case 'any':
  //       $religion = 'any';
  //       break;
  //     default:
          
  //       break;
  //   }
  // }


  if (isset($_POST['agel']) == false) {
    $agelErr = "Please enter age limit ";
  } else {

    $select3 = $_POST['agel'];
    switch ($select3) {
      case '20-25':
        $agel = '20-25';
        break;
      case '26-30':
        $agel = '26-30';
        break;
      case '31-35':
        $agel = '31-35';
        break;
      case '36-40':
        $agel = '36-40';
        break;
      case '41-45':
        $agel = '41-45';
        break;
      case '46-50':
        $agel = '46-50';
      case 'Any':
        $agel = 'Any';
        break;
      default:

        break;
    }
  }

  $male_status = "";
  $female_status = "";
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";

  } else {
    $selected_radio = $_POST['gender'];

    if ($selected_radio == 'Male') {
      $male_status = 'checked';
    } else if ($selected_radio == 'Female') {
      $female_status = 'checked';
    }
    if ($male_status == 'checked') {
      $gender = "Male";
    } else {
      $gender = 'Female';
    }
  }

  if (isset($_POST['hedu']) == false) {
    $heduErr = "Please enter Education ";
  } else {

    $select = $_POST['hedu'];
    switch ($select) {
      case 'High-School':
        $hedu = 'High-School';
        break;
      case 'Diploma':
        $hedu = 'Diploma';
        break;
      case 'BE/B.TECH':
        $hedu = 'BE/B.TECH';
        break;
      case 'PHD':
            $hedu = 'PHD';
            break;
      case 'Masters':
            $hedu = 'Masters';
            break;
      case 'BA':
            $hedu = 'BA';
            break;
      case 'BSC':
            $hedu = 'BSC';
            break;
      case 'MS':
            $hedu = 'MS';
            break;
      case 'Any':
            $hedu = 'Any';
              break;
      default:

        break;
    }
  }

  //print_r("Data submitted successfully !!");

  if ($proErr == "" && $heduErr == "" && $casteErr == "" && $relErr == "" && $genderErr=="" && $agelErr=="" && $klangErr=="" && $hErr == "") {
   
    //$link = new mysqli("localhost", "root", "root", "matrimonial_site");
    if ($link->connect_error) {
      die("Connection failed:" . $link->connect_error);
    } else {

     // $id = $_SESSION['id'];

      $query = $link->prepare("INSERT INTO pairmaking(profession ,hedu ,caste, religion, gender,	lage,	klang, height,rid) VALUES (?,?,?,?,?,?,?,?,?)");
      $query->bind_param("sssssssii", $profession,$hedu,$caste,$religion,$gender,$agel,$klang,$height,$id);
     // print_r($id);
      $query->execute();
      $query->close();
      $link->close();
      header('Location: home.php');
      //print_r("Data submitted successfully !!");
    }


  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
    #login{
        margin-left: 900px;
    }
    #gender{
      margin-left: 10px
    }
    a
    {  color:white; 
        text-decoration: none;
    }
    a:hover
    {  color: white;
        text-decoration: none;
        
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro{
        color:black; 
        text-decoration: none;
        margin-left: 15px;
   }
   #pro:hover
    {  color: black;
        text-decoration: none;
    }
  </style>
</head>

<body>
<?php include('navbar.php'); ?>
  

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
  
<div class="px-4 pt-5 my-5 ">
    <h1 class="display-4 fw-bold text-center">Match-making Information</h1>
    <div class="col-lg-10 mx-auto">
        <form class="p-4 p-md-5 border rounded-3 bg-light " name="third-form" method="post">
        
        <div class="row mb-2 ">
            <div class="col-lg-6 ">
                <label class="form-label" for="profession">Profession</label>
                <input class="form-control" type="tel" name="profession" id="profession" placeholder="Profession" value="<?php echo $profession ?>">
                <p class="error" id="proerr">
                <?php echo $proErr; ?>
                </p>
            </div>
            <div class="col-lg-6">
                <div class="form-group mb-3  ml-1">                               
                  <div><label class="form-label" for="hedu">Highest Education: </label></div>
                    <select class="form-select myopt1 p-1" name="hedu" id="hedu" style="width:280px; height:37px;">
                        <option selected >Choose...</option>
                        <option value="High-School">High School(12th)</option>
                        <option value="Diploma">Diploma</option>
                        <option value="BE/B.Tech">BE/B.Tech</option>
                        <option value="PHD">PHD</option>
                        <option value="Masters">Masters</option>
                        <option value="BA">BA(Bachelor of Arts)</option>
                        <option value="BSC">BSC</option>
                        <option value="MS">MS</option>
                        <option selected value="Any">Any</option>
                    </select>
                    <p class="error" id="heduerr">
                        <?php echo $heduErr; ?>
                    </p>
                </div>
            </div>

        </div>

        <div class="row mb-2 ">
            <div class="col-lg-6">
                <label class="form-label " for="caste">Caste</label>
                <input class="form-control " name="caste" id="caste" type="text" placeholder="Caste" value="<?php echo $caste ?>">
                <p class="error" id="casteerr">
                <?php echo $casteErr; ?>
                </p>
            </div>
            <div class="col-lg-6">
                <div class="form-group mb-3 ">
                    <div><label class="form-label" for="religion">Religion</label></div>
                    <select class="form-select myopt1 p-1" name="religion" id="religion" style="width:280px; height:37px;">
                        <option  disabled>Choose...</option>
                        <option value="Hindu"> Hindu</option>
                        <option value="Muslim"> Muslim</option>
                        <option value="Buddhists"> Buddhists</option>
                        <option value="Christian"> Christian</option>
                        <option selected value="Any">Any</option>
                    </select>
                    <p class="error" id="relerr">
                        <?php echo $relErr; ?>
                    </p>
                </div>
            </div>
        </div>    


        <div class="row" id="gender">
            <div class="col-lg-6 form-floating mb-3 p-2">

                <div class="row"><label for="inputState" class="form-label text-lg-start">Gender 
                        </label></div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="male" value="Male">
                        <label class="form-check-label" for="flexRadioDefault1">
                            Male
                        </label>
                </div>
                <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="female" value="Female">
                        <label class="form-check-label" for="flexRadioDefault2">
                            Female
                        </label>
                </div>
                <span class="error"> <?php echo $genderErr;?></span>

            </div>


            <div class="form-floating mb-3 col-lg-6 p-0">
                <div class="form-group mb-3">
                    <div><label class="form-label" for="agel" id="age">Age Limit</label></div>
                    <select class="form-select  myopt1 p-1" name="agel" id="agel" style="width:280px; height:38px;">
                        <option  disabled>Choose...</option>
                        <option value="20-25">20 - 25</option>
                        <option value="26-30">26 - 30</option>
                        <option value="31-35">31 - 35</option>
                        <option value="36-40">36 - 40</option>
                        <option value="41-45">41 - 45</option>
                        <option value="46-50">46 - 50</option>
                        <option selected value="Any">Any</option>
                    </select>
                    <p class="error" id="agelerr">
                        <?php echo $agelErr; ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="row mb-2 ">
            <div class="col-lg-6">
                <div class="form-group ">
                    <label for="klang">Known Languages</label>
                    <input type="text" class="form-control" name="klang" id="klang" placeholder="Enter known languages" value="<?php echo $klang ?>">
                    <p class="error" id="klangerr">
                      <?php echo $klangErr; ?>
                    </p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group ">
                    <label for="height">Height</label>
                    <input type="number" class="form-control" name="height" id="height" placeholder="height(in cm)" value="<?php echo $height ?>">
                    <p class="error" id="herr">
                        <?php echo $hErr; ?>
                    </p>
                </div>
            </div>
        </div>  
            
            <div class="d-grid gap-3 d-sm-flex justify-content-sm-center mb-5 mt-3 ">
                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 mr-5" id="submit" name="previous"
                    value="Previous">
                    <a href="sec-form.php"> Previous </a>
                </button>
                
                <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3" id="submit" name="submit"
                    value="submit">Submit</button>
            </div>

        </form>
    </div>
</div>








  <div class="container">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>