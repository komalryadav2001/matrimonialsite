<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

include ('smtp/PHPMailerAutoload.php');

function smtp_mailer($to, $subject, $msg)
{
    $mail = new PHPMailer(true); 

    try {
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "webaccess03@gmail.com";
        $mail->Password = "vkgkktdqzinaezpv";
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('webaccess03@gmail.com');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body = $msg;

        if (!$mail->send()) {
            return 'Error: ' . $mail->ErrorInfo;
        } else {
            return 'Sent';
        }
    } catch (Exception $e) {
        return 'Error: ' . $mail->ErrorInfo;
    }
}

echo smtp_mailer('webaccess03@gmail.com', 'Demo For send Mail', 'Hello Web');
?>