<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
//print_r($_SESSION);

// $link = mysqli_connect("localhost", "root", "root", "matrimonial_site");
// if (mysqli_connect_error()) {
//   die("There was error something while connecting.");
// }
include('connection.php');

$id=$_SESSION['id'];



$query2 = "SELECT gender,fname FROM registration where id=$id";
 $result2 = mysqli_query($link, $query2);
 $row2 = mysqli_fetch_assoc($result2);
 $gender=$row2['gender'];
 $name=$row2['fname'];


// $query3 = "SELECT fname FROM registration where id=$id";
// $result3 = mysqli_query($link, $query3);
// $row3 = mysqli_fetch_assoc($result3);
// $name=$row3['fname'];


$query = " SELECT personal.fname, personal.lname, personal.age,personal.pimg, professional.hedu , professional.profession,personal.resiterid FROM personal INNER JOIN professional ON personal.resiterid=professional.rid INNER JOIN frnd_request ON frnd_request.sender_id=personal.resiterid WHERE frnd_request.rec_id=$id AND frnd_request.status='pending'";


$result = mysqli_query($link, $query);
//print_r($result);
 $profiles= mysqli_fetch_all($result);

$query="SELECT personal.fname, personal.lname, personal.age,personal.pimg, professional.hedu , professional.profession,personal.resiterid FROM personal INNER JOIN professional ON personal.resiterid=professional.rid INNER JOIN frnd_request ON frnd_request.sender_id=personal.resiterid OR frnd_request.rec_id=personal.resiterid WHERE (frnd_request.rec_id=$id OR frnd_request.sender_id=$id ) AND frnd_request.status='approved' AND personal.fname!='$name'";

$result = mysqli_query($link, $query);
//print_r($result);
 $frnds= mysqli_fetch_all($result);

 $query = "SELECT c.sender_id,c.msg,p.fname,c.rec_id from chats c
  INNER JOIN personal p ON
  p.resiterid = c.sender_id
  WHERE rec_id=$id AND readmsg=0";
 $result = mysqli_query($link, $query);
 $msgs= mysqli_fetch_all($result);

 $msgCount=count($msgs);

 $test="";
$arr_length=count($profiles);

$length=count($frnds);
$test .= '<div class="container row mb-2"> ';
 for($i=0;$i<$length;$i++){

    $test .='
            <div class="col-lg-4">
            <div class="card" style="margin-top:20px; padding:11px; border-radius:5px; width:250px">
                <img class="card-img-top" src="profile/'.$frnds[$i][3].'" alt="Card image cap" style="width: 230px; height: 250px;"> 
                <div class="card-body">
                    <p class="card-text"> Name : '.$frnds[$i][0].' '.$frnds[$i][1].' </p>
                    <p class="card-text"> Age : '.$frnds[$i][2].' </p>
                    <p class="card-text"> Profession : '.$frnds[$i][5].' </p>
                    <p class="card-text"> Education : '.$frnds[$i][4].' </p>
                    <button type="submit" class="btn btn-primary btn-lg px-4 me-sm-3 align-content-center text" id="profile" name="profile"
                    value="Profile">  <a id="profile" href="profile.php?id='.$frnds[$i][6].'" style="color:White; text-decoration: none"> Profile </a></button>
                </div>
            </div>
            </div>
            ';
 }
 $test .= '</div>';



$test .= '<div class="container row mb-2"> ';
 for($i=0;$i<$arr_length;$i++){

    $test .='
            <div class="col-lg-4">
            <h1 class="text-center mt-5 mb-5">Friends Requests</h1>
            <div class="card" style="margin-top:20px; padding:11px; border-radius:5px; width:250px">
                <img class="card-img-top" src="profile/'.$profiles[$i][3].'" alt="Card image cap"> 
                <div class="card-body">
                    <p class="card-text"> Name : '.$profiles[$i][0].' '.$profiles[$i][1].' </p>
                    <p class="card-text"> Age : '.$profiles[$i][2].' </p>
                    <p class="card-text"> Profession : '.$profiles[$i][5].' </p>
                    <p class="card-text"> Education : '.$profiles[$i][4].' </p>
                    <a href="request.php?id='.$profiles[$i][6].'&status=1" class="btn btn-primary">Approve</a>
                </div>
            </div>
            </div>
            ';
 }
 $test .= '</div>';
//print_r($profiles);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shaadi.com</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    .error {
      color: red;
      font-weight: bold;
      margin-left: 5px;
    }
  
    .about{
        float: left;
        margin-right: 10px;
    }
    #logout
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #logout:hover
    {  color: black;
        text-decoration: none;
    }
    #pro
    {  color:black; 
        text-decoration: none;
        margin-left: 15px;
    }
    #pro:hover
    {  color: black;
        text-decoration: none;
    }
   
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">shaadi.com</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item mx-2">
            <a class="nav-link " aria-current="page" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about-us.php">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us.php">Contact Us</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Profile
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="first-form.php">Personal Information Form</a>
              <!-- <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="sec-form.php">Professional Information Form</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="third-form.php">Match-making Information Form</a> -->
            </div>
          </li>
            <form class="form-inline my-2 my-lg-0 mr-3" action="find_profile.php" method="POST">
              <input class="form-control mr-sm-2 me-2 " type="search" name="filter" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success my-2 my-sm-0 mr-3" type="submit">Search Match</button>
            </form>

        </ul>
     
          <div class="nav-item dropdown">
            <?php
                if($msgCount > 0){
                  echo '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                   '.$msgCount.' </span>';
                }
            ?>
            
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fa-solid fa-bell" style="color: #ffffff;"></i>
              </a>
              
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <?php 
                  for($i=0;$i<$msgCount;$i++){

                    echo ' <a id="logout" href="readmsg.php?sid='.$msgs[$i][0].'&rid='.$msgs[$i][3].'&redirect=true">'.$msgs[$i][2].':'.$msgs[$i][1].'</a>';
                  }
              ?>
              </div>
          </div>
          <label value="<?php echo $name; ?>" style="color:white; margin-left:420px"> <?php echo $name; ?> </div>
          <div class="nav-item dropdown" style="margin-bottom: ">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-list" fill="white" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M2 2.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5z"/>
              </svg>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a id="logout" href="logout.php">Log Out</a>
              <div class="dropdown-divider"></div>
              <a id="pro" href="own_profile.php">Profile</a>
            </div>
          </div>
            <!-- <button class="btn btn-outline-success mr-sm-2 ml-2" type="submit" ><a id="logout" href="logout.php">Log Out</a></button> -->
    
    </div>
  </nav>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="#c1">
            <img class="d-block w-100" src="img/c1.jpg" alt="First slide">
            </div>
            <div class="carousel-item" id="#c2">
            <img class="d-block w-100" src="img/c2.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="img/c3.webp" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
  
    


    <div class="container" style="margin-bottom:100px">
     
        <h1 class="text-center mt-5 mb-5">Search Your Match-making Here !!</h1>
       <div><?php 
            echo $test;
       ?></div> 
       
    </div>


    <section class="my-5">
        <div class="py-5">
            <h1 class="text-center">Why Choose Shaadi.com!</h1>
            <h3 class="text-center">Genuine Profiles | Safe & Secure | Detailed Family Information</h3>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-12">
                    <img src="img/w.png" class="img-fluid">
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <img class="about" src="img/a1.svg"> <h3 class="text-left info">Get Complete Family Information</h3> 
                    <p>You will find detailed family information in every profile. Knowing the family<br> 
                        will help you take the next step with confidence.</p><br>

                    <img class="about" src="img/a2.svg"> <h3 class="text-left info">Get Matches from your Community</h3> 
                    <p>With over 80 community sites, you can find a Match from your community.<br> 
                        Finding a Match based on caste and religion made easy.</p><br>

                    <img class="about" src="img/a3.svg"> <h3 class="text-left info">Enable your search without any barrier</h3> 
                    <p>Embark on your journey to find your perfect match now available in multiple <br> languages.</p><br>

                </div>
            </div>
        </div>
    </section>

    

  <div class="container mt-5">
    <div class="row mx-5 pl-5">
      <div class="col-lg-3 mx-3 ">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w3.webp" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Radha & Krish Yadav</h5>
            <p class="card-text">I met my soulmate beacuse of shaadi.com, Heartly thank you to shaadi.com .</p>

          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;">
          <img class="card-img-top" src="img/w1.jpg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Lilly & Rob Mattia.</h5>
            <p class="card-text">Meeting your soulmate is such a dream, thank you shaadi.com for make possible.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-3 mx-3">
        <div class="card c-box" style="width: 18rem;" style="background-color: #d3cbcb;">
          <img class="card-img-top" src="img/w2.jpeg" alt="Card image cap" style="height: 200px;">
          <div class="card-body">
            <h5 class="card-title">Shubham & Nidhi</h5>
            <p class="card-text">Thank you to the team. I will
              always be thankful to you throughout my life.
            </p>

          </div>
        </div>
      </div>
    </div>

  </div>

  </div>
  <footer class="bg-dark text-secondary text-center p-5 mt-5" style="width: 100%;">
    <div>
      <h1 class="display-6 fw-bold text-white ">shaadi.com - Join 3 Million Members with Photos</h1>
      <div class="mx-auto col-lg-10"></div>
      <p class="lead  mb-4">shaadi.com, one of India's best known brands and the world's largest matrimonial
        service
        was founded with a simple objective - to help people find happiness. The company pioneered online matrimonials
        in 1996 and continues to lead the exciting matrimony category after more than a decade. By redefining the way
        Indian brides and grooms meet for marriage, Shaadi.com has created a world-renowned service that has touched
        over 35 million people</p>
      <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-light mr-5">Join Today!</button>
        <button type="button" class="btn btn-outline-primary">See Catlog</button>
      </div>
  </footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>