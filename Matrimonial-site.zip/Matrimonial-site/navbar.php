<?php
$query2 = "SELECT fname FROM registration where id=$id";
$result2 = mysqli_query($link, $query2);
$row2 = mysqli_fetch_assoc($result2);
$name=$row2['fname'];
?>

<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">shaadi.com</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item mx-2">
            <a class="nav-link " aria-current="page" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about-us.php">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us.php">Contact Us</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Profile
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="first-form.php">Personal Information Form</a>
              <!-- <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="sec-form.php">Professional Information Form</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="third-form.php">Match-making Information Form</a> -->
            </div>
          </li>

        </ul>
        <div><lable value="<?php echo $name; ?>" style="color:white; margin-left:890px"> <?php echo $name; ?> </div>
        <div class="nav-item dropdown" style="margin-bottom:">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-list" fill="white" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M2 2.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1H2.5a.5.5 0 0 1-.5-.5z"/>
            </svg>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a id="logout" href="logout.php">Log Out</a>
            <div class="dropdown-divider"></div>
            <a id="pro" href="own_profile.php">Profile</a>
          </div>
        </div>
            <!-- <button class="btn btn-outline-success mr-sm-2 ml-2" type="submit" ><a id="logout" href="logout.php">Log Out</a></button> -->
      </div>
    </div>
  </nav>